---
name: ocap-spec-grill
description: Dual-mode OCAP planning for interactive conversation and non-interactive Agent CLI. Auto Grill chooses the smallest maintainable, compatible and evidence-backed approach without unsafe assumptions; preserves prompt traceability and regenerates HumanReview.md.
---

# ocap-spec-grill

直接輸入 `/ocap-spec-grill` 即可。`SKILL.md` 只負責 Workflow + Global Rules；規劃細節與 canonical 文件由 `references/blocks/*.md` 決定。

## Runtime Context
所有積木共享：
- 本次 user prompt，以及同一需求後續明確補充/決策；後來的明確決策可取代較早衝突內容。
- Repository / workspace / instructions / relevant code/tests/contracts/storage。
- canonical planning docs：`Spec.md / Architecture.md / TestPlan.md / TODO.md`。
- `HumanReview.md`（derived view，不是 source of truth）。
- `spec_review_*.md`、既有 implementation review history、完成歷史。
- 本輪新 evidence / 使用者回答。

有新 prompt 必須納入所有積木；已有 `ocapspec/` 且無新 prompt 時直接延續，不要求重述需求。

## Grill Mode Selection
共用原有 `/ocap-spec-grill`，不新增 Skill 或 CLI 指令：
- `INTERACTIVE`（預設，確實可持續收取 user 回答的聊天環境）：沿用最多 3 題/輪的 Grill。
- `AUTO`：使用者指定 `--auto` / `auto grill` /「自行決定、不需反問」，或**確實屬於不能等待回覆的 Agent CLI、腳本、CI、無人值守 pipeline** 時，自動選用。
- 明確知道沒有可用的互動回覆通道，就算使用者沒寫 `--auto` 也必須用 `AUTO`；**不可呼叫互動提問工具或等待 stdin/人類回答**。
- 不可只因看到「CLI」字樣，就推斷聊天中的使用者無法互動；模式以實際執行情境、明確參數/指示為準。
- 已明確要求互動但環境確實不能互動時，不能假裝可互動；先遵守不詢問規則，只在有證據可安全決策時繼續，否則 `BLOCKED`。
- 每次在 `Spec.md` 的 `## Planning Baseline` 記錄 `Grill Mode: INTERACTIVE | AUTO` 和簡短選用原因；切換模式本身不構成 material planning change，不因此升 `Plan Revision`。

## Auto Grill Decision Policy
`AUTO` 是**自行做保守的技術規劃決策**，不是自行新增或修改使用者需求。
1. 先對照 prompt/已確認決策、Repo 實況、既有 caller/contract/data/behavior、tests。能從事實推得的答案直接用證據解決，不詢問。
2. 針對剩下的技術選擇只比較少數真正可行方案；必要時列 1–3 個候選，不必湊數。
3. 按以下**先後次序**判斷，絕不是單純 LOC 最小：
   - **正確與相容性**：符合 Acceptance；保護既有 behavior、API/DB/資料、授權、安全、恢復語意；不宣稱未知的影響為 0。
   - **最小影響**：優先沿用既有 code path、service、library、schema、project convention；減少跨專案改動和 regression surface。
   - **可維護與可驗證**：簡單、可讀、易測、有明確責任；避免硬塞一個 function、code golf、隱藏副作用。
   - **避免過度設計**：沒有現在需求的理由，不新增 framework/service/layer/dependency/schema、泛用 abstraction 或順手重構。
   - **改動量**：在上述條件相當時，優先檔案/LOC 少、部署或回滾簡單的方案；LOC 只能合理估計，不偽造數據。
4. 如果無法做到「完全不影響」原功能，選**滿足需求的最小必要影響**方案，具體列明既有功能/呼叫者、regression 測試與減緩方式；不能因偏好少行程式碼犧牲正確性。
5. 每個有實質影響的自行決策在 `Spec.md` 的 `## Decisions / Assumptions` 以 `AI_SELECTED` 標記，寫一個精簡記錄：`選擇 | 依據(Repo/prompt) | 被排除的可行替代方案/原因(如有) | 原功能影響/風險 | 如何驗證`。不得寫成 `USER_CONFIRMED`，也不得把臆測稱為已查證。
6. 非阻擋性的資訊不完整，可作**明確標示、可逆且保守**的 `ASSUMPTION`，附可驗證條件；不可把未確認的重大假設轉成已確認需求。
7. 下列屬**不可安全自行決定**的阻擋情境：需求/Acceptance 互相矛盾且 Repo 無法消歧、可能破壞既有 API/資料/授權與安全邊界、不可逆 migration/刪除、重大 state/recovery 語意改變、需要新增使用者未授權的產品行為且無可保守避開方案。盡可能完成可確定的規劃，記錄 `BLOCKING_DECISION`、需使用者判斷的選項及影響；回 `BLOCKED`，**不宣告 `CONVERGED`、不把該項變成可執行 TODO**。
8. 所有 Core/Extension Blocks 共用相同模式與決策優先序；Auto 不逐輪 Grill，不對使用者發問，分析後寫回 canonical docs、產出 HumanReview，再自我驗證。可行且沒有 blocker 才 `CONVERGED`。


## Workflow
1. Discover：掃 `references/blocks/*.md`。
2. Validate：
   - Required Core Blocks：`requirements`、`architecture`、`testing`、`todo`。
   - 缺任一 Core Block、重複 block、frontmatter/type 不合法或缺必要 Section → `BLOCK_CONFIG_ERROR`。
   - 每個 block 必須有唯一 `block`、整數 `priority`、boolean `always`，以及 `Match / Analyze / Grill / Writeback / Complete`。
3. Spec Review Intake：掃 `spec_review_*.md`；未完成的 blocking `SR#`（舊版未標註 blocking 的 SR# 保守當 blocking；`SUPERSEDED/NON_ACTIONABLE` 除外）才是 planning work。`## Observations` 非待辦，不阻擋 `CONVERGED`。
4. Select：Core Blocks 永遠參與；Extension Blocks 依 `always/Match`。priority 高到低。
5. Mode：依 `Grill Mode Selection` 判定 `INTERACTIVE` 或 `AUTO`；所有積木共用同一模式。
6. Analyze：所有適用 block 讀同一 Runtime Context，包含 user prompt 與 SR# evidence。
7. Decide / Grill：
   - `INTERACTIVE`：彙整、去重高影響未決問題；每輪最多 3 題，只問會改變需求、架構、相容性、資料、錯誤恢復或驗收的問題；收到回答後更新 Context 並重新分析。
   - `AUTO`：不向人提問；依 `Auto Grill Decision Policy` 自行選最小、安全、可維護的方案；無法安全決定時記 `BLOCKING_DECISION`，回 `BLOCKED`。
8. Writeback：各 block 更新 canonical 文件與選擇依據；若正在處理 SR#，在原 `spec_review_00X.md` 的 SR# 寫 `Resolution/Evidence`，**只有真正處理完才勾選**，保留原 Verdict/history。`AUTO` 如有 blocker，可保存非阻擋部分與理由，但不可產生可直接執行的假定結論。
9. Generated-MD Reconciliation：依全域規則同步所有受影響的 `ocapspec/**/*.md`；若本次 material replan 使舊 Spec Review 過期，標記舊 review `STALE/SUPERSEDED`，不覆寫原 Verdict。
10. Regenerate Human Review：依 `HumanReview.md Contract` 從最新 canonical docs/review validity **完整重建**規劃版 `ocapspec/HumanReview.md`；Spec Review 與 Final Review 狀態分開，Final Review 尚未執行時固定 `NOT_RUN`，`HumanFinalReview.md` 顯示 `NOT_CREATED`（若舊檔存在但 snapshot 已失效則標 `STALE`）。
11. 重新跑 blocks + cross-doc reconciliation；所有適用 blocks Complete、文件無已知 stale、沒有未解重大決策與 blocking SR# 才 `CONVERGED`。

## Planning Baseline & Prompt Provenance
- `Spec.md` 固定有 `## Planning Baseline`，包含 `Plan Revision: <positive integer>`；新需求首次建檔用 `1`，延續既有規劃要保留並單調遞增，不可重設/覆蓋歷史。
- 只在**material planning change** 增加 Revision：user 新需求或明確決策改變 Requirement/Acceptance/保護行為、Planned Architecture/Contract、預期 Validation 設計或 TODO 工作範圍。
- 格式整理、修正無語意錯字、TODO checkbox/evidence、實作後的 Actual/LOC/Drift、測試執行結果、重建 HumanReview **不增加 Revision**。Implement 不得透過修改 Planning Baseline 迴避 Spec Review。
- `Spec.md` 同時保留精簡的 `## Requirement Sources`：對每個主要 R# 記「原始 prompt 的關鍵要求、後續明確決策、重要禁止/不變條件」及可取得的來源線索。來源摘要不是原 prompt 的替代品，不要捏造未曾說過的要求，也不要複製金鑰/密碼等 secrets。
- Spec Review 應優先比對**實際可取得的 user prompt/決策**。跨 Session 找不到原文時，必須揭露可驗證範圍；若缺失會影響重要需求真偽，應 `BLOCKED`，不可假裝完整比對。
- `HumanReview.md` 只根據 canonical facts 產生，不另設版本或獨立決策；對 AI 選定但尚未驗證的方案須保留 `AI_SELECTED / 待驗證` 標示，不能當使用者已核准。

## 通用 Change Surface
OCAP 預設用於軟體/技術交付，但不只限一般 application code。以下都可以套用：
- runtime/application code、library/SDK、CLI/script。
- API/contract、DB/schema/migration、persisted data。
- config、YAML、CI/CD、build/deploy、infra/IaC。
- worker/background job、observability、security/reliability behavior。
- docs-only / contract-only change。

規則：
- 沒有 runtime/code 變更時，Architecture/TestPlan 可以精簡或標 N/A，不硬造 code sketch、coverage 或 E2E。
- docs/config/infra/migration 類需求仍要回答：改什麼、可能影響什麼、如何驗證。
- 只有真的可量測 code coverage 時才要求 line/branch coverage；其他類型改用最接近真實風險的 validation/evidence。

## Core vs Extension
- `requirements / architecture / testing / todo` 是 Planning Core Blocks。
- migration/security/performance 等額外規劃能力使用 Extension Block。
- 新增/移除 Extension 不需改主 Workflow。
- Extension 不得要求另一個特定 Extension 一定存在；可依 Core 產物工作。

### Persistent Work Contract
Extension 若留下 Implement 可執行 work：
- 必須放 `## Actionable Work`（含子 section）。
- stable ID，例如 `M1 / SEC2 / PERF3`：`- [ ] M1 ...`。
- Core `TODO.md` 使用 `## TODO`；implementation Review 使用 `## Review TODO`。
- **Spec Review 使用 `## Spec Review TODO`，只由 `/ocap-spec-grill` 消化，不屬於 implementation work。**
- 不得另創可執行 queue heading。

## Global Generated-MD Reconciliation（所有 Skill 共用）
任何 OCAP Skill 執行時，只要取得的新 prompt、Repo、diff、test、coverage、review、runtime evidence 顯示**已產生的 Markdown 與現況不一致**，就必須在該次 invocation 內同步所有受影響的 generated md；不能因「這不是本 Skill 原本負責的文件」而留下 stale 狀態。

### 必須掃描的 generated md
至少包含存在的：
- `ocapspec/Spec.md`
- `ocapspec/Architecture.md`
- `ocapspec/TestPlan.md`
- `ocapspec/TODO.md`
- `ocapspec/HumanReview.md`
- `ocapspec/HumanFinalReview.md`（若已產生；僅 Final Review 建立，其他 Skill 只同步/標 STALE）
- `ocapspec/spec_review_*.md`
- `ocapspec/review_*.md`
- 其他由 OCAP block/extension 產生且與本次 evidence 有關的 `ocapspec/**/*.md`

### Reconcile 規則
1. **Current-state docs 直接同步現況**：檔案/Project/Function Call & Data Flow、Actual LOC、contract/data/state、test cases、coverage/evidence、TODO 狀態、風險、未驗證項等有新事實就更新。
2. **Requirement truth 不可被 implementation 倒推改寫**：若 actual code 與 user prompt/已確認 Requirement 不同，文件要同時保留「要求」與「Actual Drift」，標 `NEED_REPLAN/FAIL/BLOCKED`（依 Skill），不能把 Spec 改成配合錯誤實作來製造一致。
3. **Material planning change** 依 Planning Baseline 增加 `Plan Revision`；任何綁舊 Revision 的 Spec Review PASS 都標 `STALE/SUPERSEDED`，必須重新 Spec Review。
4. **Review history 保留原始證據**：`spec_review_00X.md` / `review_00X.md` 的原 Verdict、finding、snapshot、evidence 不覆寫、不刪除。後來 evidence 改變有效性時，可追加/更新 `## Current Validity / Reconciliation`，標 `VALID / STALE / SUPERSEDED`、原因與替代的最新 review。
5. **HumanReview 永遠重建為最新人工入口**：從 canonical docs + 最新有效 Review + actual evidence 衍生；不得保留已知 stale flow、檔案清單、測試結果或 Review 狀態。
6. 同一 invocation 在輸出 PASS/READY/CONVERGED/SCOPE_COMPLETE 前，必須再次做 cross-doc consistency check；仍有已知 stale generated md 就不能宣告完成。
7. Auto-sync 只更新 Markdown/衍生狀態，不代表 Reviewer 可以修改 production/test code。只有 `/ocap-implement` 依 work item 修改交付內容；Spec/Final Review 仍保持 implementation independence。

## HumanReview.md Contract — 少而精確的人工決策頁
`ocapspec/HumanReview.md` 是整個流程共用的衍生摘要，不是第二份 Spec。**Final Review 的詳細人工驗收另由 `/ocap-review` 產生 `ocapspec/HumanFinalReview.md`**；規劃/Spec Review 階段不預先建立假 Final Review 文件。
- **先判斷，再看證據**：只留下「要做什麼／真的改什麼／**主要 Function Call / Data Flow**／最重要的風險／如何驗收／是否可接受」。先看一頁摘要即可決策；複雜多專案也先列重點，不把所有技術表格複製過來。
- 繁體中文、短句、無空泛稱讚。一般需求以約 30–50 行為可讀性目標；大需求以一頁摘要 + 指向既有 Architecture/TestPlan/Review 的精確位置為主，**不為達到行數限制而隱藏風險**。
- 同一事實只講一次：不要在摘要、CRUD、Function Call Flow、E2E、最終審核和 acceptance 指引重複貼同一段敘述。stable IDs、完整 dependency/contract/test matrix、所有 Test Cases、長 pseudocode 留在 canonical docs。
- 所有重要產品改動與高風險刪除都要可定位；低風險小檔案可依同一目的合併成一行並指向 `Architecture.md > Change Map`，不可只寫「修改數個檔案」。
- 從 `Spec.md / Architecture.md / TestPlan.md / TODO.md` 以及真實 git diff / review / test evidence 衍生，不新增需求或猜測檔案。已確認的需求不再列為「待使用者決定」；未知影響明寫待查證，**沒有證據不得說不影響**。
- 規劃時只能寫預計/尚未執行；實作後要列真實 Actual、偏差（含主要呼叫/資料流變更）、最後一次 scope/snapshot/Review 與未驗證；Review 不能因重新生成 HumanReview 而修改程式、測試或 Verdict。

**固定五個短區塊**；可合併重複列、精簡欄位，但不得漏高風險資訊：

### 1. 決策摘要（最多 4–5 點）
- `需求/不變`：改什麼；重要舊功能、資料、API/contract 哪些必須保留。
- `範圍`：只列真正修改 production 的 Project 數與名字；TEST_ONLY/保護不動的相關 Project 一句補充。
- `風險/待決策`：只列最高的 1–3 點；已決定就不要再問；AUTO 選定重要方案只需一句理由。
- `階段`：規劃待審 / 實作中 / 待驗收 / FAIL / BLOCKED / 已由人接受（**必須有真人證據**）。

### 2. 改動重點（Project + C/U/D）
- 多專案先放**簡短影響概覽**：`MODIFY: ...；TEST_ONLY: ...；保護不動: ...`；只有分類本身有爭議時才用完整 Project 表格。
- 以一張精簡表列各個**主要 production/delivery file**：`Project / C-U-D + File::Method / 原→新 / 原功能影響 / 預計→實際 LOC`。資料要具體、可查到；同目的低風險檔可合併，重要 C/D、DB/schema、security、public API 一律單列。
- 跨專案重大 contract，只追加**最多 1–3 個**必須由人確認的 producer→consumer 相容性或 rollout/rollback 判斷。完整 dependency matrix 放 Architecture，不在此複製。
- 多出計畫外專案、無必要 Service/框架/DB/依賴、刪掉原功能或 breaking change，直接標 `需人工確認/退回`；不能藏在附註。

### 2a. 主要資料流 / Function Call Flow（第 2 區的一部分）
- **人必須能看懂主要呼叫順序**：從哪個入口（API/UI/Job/CLI）開始，依序呼叫哪些實際 `Project.Class.method()`、跨哪個專案邊界、傳遞什麼關鍵資料，何處讀寫 DB/事件/外部 API，以及結果/錯誤如何返回。不可只用「Controller → Service → DB」取代能查證的主要函式。
- **預設一張精簡 Mermaid 圖**：跨專案或非同步呼叫用 `sequenceDiagram`；以資料變換/分支為主用 `flowchart`；極小純文件/設定變動可用 1 行文字流程或標 `N/A` 並說明，不強迫畫假圖。
- 圖只選**本次變更涉及的一條關鍵端到端路徑**，一般 3–6 個參與者、約 5–9 個主要步驟；重要錯誤/回退/相容性分支只保留 1–2 個。詳細替代流程、所有方法與完整序列留在 `Architecture.md > Function Call & Data Flow`。有兩條互不相干的高風險流程時才增加第二張，不為湊數畫圖。
- 每個箭頭須能從 `Architecture.md` 的入口/caller/contract 或實際程式驗證；標清楚 **同步函式呼叫**、**事件/HTTP/Queue/資料交接**、**DB 讀寫**，避免把 consumer 誤畫成 producer 直接呼叫。未實作的通訊鏈路、尚待確認的跨 repo 呼叫必須標 `PROPOSED` / `待查證`，不可捏造傳輸機制或 runtime call。
- **規劃與實際分清楚**：規劃圖標 `Planned`，實作後檢查 git diff/callers 並更新成 `Actual`；若呼叫順序、跨專案連線、資料欄位/錯誤語意改了，指出 `Planned → Actual` 差異及是否需要 Replan，不能靜默換圖。
- 圖下只補 **1 句白話重點**：人應確認的主要資料/相容性邊界；不重複第 1 區摘要或完整 Contract Matrix。
### 3. 最重要的驗收與測試檔
- 依真實風險只顯示 **2–5 個**最有價值的 `[MUST-REVIEW]`（小變更可 1 個）；每項寫：`條件→預期→保護什麼`，同時列**實際對應的 Test File::Method**，有實測結果才加 PASS/FAIL。
- 負面／邊界／舊 caller 回歸／跨專案部署順序要優先；尤其**值缺失、明確 null、0、空字串、錯誤型別**等不同語意，只有與需求有關才保留，不機械式湊齊。
- TestPlan 保留完整測試 C/U/D 與所有方法；每個新增或修改 Test Case 的原始程式碼仍要有清楚名稱 + 就近短 docstring/comment，描述「條件、預期、保護的原功能」，不得因 HumanReview 精簡而刪除。
- 真正需要人關注的測試檔新增/刪除或大幅修改可補一行；其餘測試清單以 `TestPlan.md > Planned Test File Change Map` 定位，不重貼 20–100 個案例。

### 4. Review 狀態（Spec Review 與 Final Review 分開）
- **Spec Review（實作前）**：只報 `Plan Revision | FULL/SCOPED | PASS/FAIL/BLOCKED/NOT_RUN | spec_review_00X.md | Prompt Evidence`。它回答「規劃是否正確、完整、可安全實作」，不代表實作已正確。
- **Final Review（實作後）**：只報 `Reviewed Code Snapshot | FULL/SCOPED | PASS/FAIL/BLOCKED/NOT_RUN | review_00X.md | Tests/Coverage | Unverified`。它回答「實際 code 是否符合需求且穩定、是否改 A 壞 B」。
- 實作後補 `原估→實際 Project/File/LOC` 與重大 drift；規劃階段 Final Review 固定 `NOT_RUN`，不得把 Spec Review PASS 當 Final PASS。
- Review 後任何相關 production/test code 改變，Final Review PASS 標 `STALE`；material plan 變更則 Spec Review PASS 也標 `STALE`。Scoped PASS 不能當 Full PASS。

### 5. 人最後怎麼審（最多 3 點）
1. **符合需求嗎？** 只看第 1 區與重要驗收。
2. **改動與呼叫流程合理嗎？** 核對第 2 區的「不該改的 Project」及 Function Call / Data Flow，確認主要函式、跨專案資料交接、舊 caller/相容性；細節看 `Architecture.md > Function Call & Data Flow / Change Map`。
3. **Final Review 要我確認什麼？** 優先照最新 `review_00X.md > Human Final Review Focus` 核對需求主流程、受影響舊功能/相鄰功能、跨專案/資料/狀態邊界、最高價值 E2E/Regression 與未驗證範圍；全部有證據且最新 Full Final Review snapshot 有效，才 `接受 <Plan Revision + Snapshot>`，否則 `退回 <具體檔案/情境/原因>`。
- 人工接受/退回只能依真實使用者明確回覆，寫進 `Spec.md` 或 `TODO.md ## Human Acceptance`；`HumanReview.md` 只能展示衍生狀態，不自行核准。

## Global Rules
- user prompt 與後續明確決策是一級需求來源，不能只相信已生成文件。
- 需求沒要求就不改；保護既有 behavior / contract / persisted data / flow。
- 最小設計、先 reuse；禁止為未來可能需求過度設計。
- Repository 可驗證時不虛構 path/function/API/DB。
- 已完成 T#、SR# resolution、test evidence、review history、actual facts 不可靜默刪除或重編。
- 新決策推翻歷史時保留 traceability，必要時標 `SUPERSEDED`。
- 只規劃：不修改 production code、不跑正式測試、不 commit、不 push。

Block 規則與 Global Rules 衝突時，以 Global Rules 為準。

## Status
- `CONVERGED`：所有適用 blocks Complete、HumanReview 已含規劃改動清單與測試計畫、無 blocking SR#、無重大未決問題（`AUTO` 包含 AI 選擇有 evidence 且無 blocker）。
- `NEED_INPUT`：互動模式仍有重大問題要 Grill。
- `BLOCKED`：`AUTO` 無法安全自行決策；清楚留下阻擋事項/可選方案/影響，CLI 可以結束本次規劃，不等待輸入。
- `BLOCK_CONFIG_ERROR`：Core/registry/block contract 不合法。
