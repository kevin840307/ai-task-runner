---
name: ocap-review
description: Post-implementation Final Review. Independently verify the actual change against requirements, regressions and stability, reconcile generated Markdown, persist blocking fixes, and tell the human exactly what to review before acceptance.
---

# ocap-review

直接輸入 `/ocap-review` 即可。這是 **Post-Implementation Final Review**：驗證實際 implementation 是否符合需求、穩定、沒有「改 A 壞 B」。`SKILL.md` 負責 Workflow、Severity、Critical Sweep、Final Review history、人工驗收焦點與 Verdict；領域檢查細節由 `references/blocks/*.md` 決定。

## Runtime Context
- **user prompt / 後續明確決策**：原始 requirement、補充、scope、限制、focus、指定 diff/range；較新的明確決策可取代較早衝突內容。
- Repo/workspace/instructions/git change set。
- `ocapspec/`、既有 review history。
- tests/build/lint/typecheck/coverage 與可重現 evidence。

User prompt 是一級 review source：實作必須同時符合 prompt/後續明確決策與 canonical plan。不得只拿 Spec 當 Requirement truth；prompt 可縮小 Review scope或增加重點，但不能要求忽略已知嚴重 finding 或製造假 PASS。

## Global Generated-MD Reconciliation（所有 Skill 共用）
任何 OCAP Skill 執行時，只要取得的新 prompt、Repo、diff、test、coverage、review、runtime evidence 顯示**已產生的 Markdown 與現況不一致**，就必須在該次 invocation 內同步所有受影響的 generated md；不能因「這不是本 Skill 原本負責的文件」而留下 stale 狀態。

### 必須掃描的 generated md
至少包含存在的：
- `ocapspec/Spec.md`
- `ocapspec/Architecture.md`
- `ocapspec/TestPlan.md`
- `ocapspec/TODO.md`
- `ocapspec/HumanReview.md`
- `ocapspec/HumanFinalReview.md`（若已產生；僅 Final Review 建立，其他 Skill 只同步/標 STALE）
- `ocapspec/spec_review_*.md`
- `ocapspec/review_*.md`
- 其他由 OCAP block/extension 產生且與本次 evidence 有關的 `ocapspec/**/*.md`

### Reconcile 規則
1. **Current-state docs 直接同步現況**：檔案/Project/Function Call & Data Flow、Actual LOC、contract/data/state、test cases、coverage/evidence、TODO 狀態、風險、未驗證項等有新事實就更新。
2. **Requirement truth 不可被 implementation 倒推改寫**：若 actual code 與 user prompt/已確認 Requirement 不同，文件要同時保留「要求」與「Actual Drift」，標 `NEED_REPLAN/FAIL/BLOCKED`（依 Skill），不能把 Spec 改成配合錯誤實作來製造一致。
3. **Material planning change** 依 Planning Baseline 增加 `Plan Revision`；任何綁舊 Revision 的 Spec Review PASS 都標 `STALE/SUPERSEDED`，必須重新 Spec Review。
4. **Review history 保留原始證據**：`spec_review_00X.md` / `review_00X.md` 的原 Verdict、finding、snapshot、evidence 不覆寫、不刪除。後來 evidence 改變有效性時，可追加/更新 `## Current Validity / Reconciliation`，標 `VALID / STALE / SUPERSEDED`、原因與替代的最新 review。
5. **HumanReview 永遠重建為最新人工入口**：從 canonical docs + 最新有效 Review + actual evidence 衍生；不得保留已知 stale flow、檔案清單、測試結果或 Review 狀態。
6. 同一 invocation 在輸出 PASS/READY/CONVERGED/SCOPE_COMPLETE 前，必須再次做 cross-doc consistency check；仍有已知 stale generated md 就不能宣告完成。
7. Auto-sync 只更新 Markdown/衍生狀態，不代表 Reviewer 可以修改 production/test code。只有 `/ocap-implement` 依 work item 修改交付內容；Spec/Final Review 仍保持 implementation independence。

## Spec Review vs Final Review
- `spec_review_00X.md` = 實作前規劃品質；`review_00X.md` = 實作後 **Final Review**，兩者不可互相替代。
- Final Review 必須重新對照 user prompt + current canonical docs + actual diff/tests，不因 Spec Review PASS 就降低檢查。
- Final Review 的核心問題：`需求真的完成嗎？`、`主要 flow/資料/狀態正確嗎？`、`原有/相鄰功能有沒有 regression？`、`跨專案 contract/rollout 穩定嗎？`、`證據足夠讓人接受嗎？`

## Workflow
1. Discover：掃 `references/blocks/*.md`。
2. Validate：每個 check block 必須有唯一 `block`、`role: check`、整數 priority、boolean always，以及 `Match / Inspect / Findings / Complete`。
3. Select Checks：
   - `always: true` = **任何 Review 都執行，Match 不作 gating**；Match 只可描述 scope/適用方式。
   - `always: false` = **只有 Match 成立才執行**。
4. Run：依 priority 高到低執行所有 selected checks。
5. Aggregate：以 root cause 合併重複 finding，保留最強 evidence/impact；不同 check 不重複報同一問題。
6. Normalize severity。
7. **Critical Sweep**：基於所有 evidence/change surface 做一次災難級後果檢查，確認沒有漏掉資料毀損、Auth bypass/RCE/重大 secret exposure、不可逆破壞、核心 state corruption、crash loop、重大重複副作用、嚴重 race/recovery failure、核心無人值守流程全面失效。這是 Workflow safety gate，不是額外 finding domain；若已由 check 發現，只升級/合併。
8. Generated-MD Reconciliation：依 current diff/tests/runtime evidence 更新所有受影響 `ocapspec/**/*.md`；actual facts 可直接同步，Requirement mismatch 必須同時保留 user intent + `ACTUAL_DRIFT`，不能把 Spec 改成配合錯誤 code。若 material planning change，舊 Spec Review 標 STALE 並要求重新 Spec Review。
9. Determine Verdict。
10. Build **Human Final Review Focus**：從本次 changed surface、Function/Data Flow、protected behavior、regression matrix、failure/recovery/data/contract 風險挑 3–7 個**人真的需要確認**的項目；每項包含 `Review area | 為何重要/可能改 A 壞 B | 人要看什麼 | Evidence/Test | PASS/Unverified`，不可使用空泛 checklist。
11. Persist Final Review：建立下一個 `ocapspec/review_00X.md`，包含實際 Verdict、scope、snapshot、test evidence、`## Human Final Review Focus` 與 blocking `## Review TODO`。
12. **Generate `ocapspec/HumanFinalReview.md`**：每次 `/ocap-review` 都從**本次最新 `review_00X.md` + canonical docs + actual diff/tests/snapshot**完整重建，不從舊 HumanFinalReview 疊加。它是「最新 Final Review 的人工驗收頁」，不是 review history；PASS/FAIL/BLOCKED 都要產生。內容依 `HumanFinalReview.md Contract`。
13. **Publish Final Human View**：從最新 generated md + 本次 review 重建 `HumanReview.md` 的 Final Review 狀態與一行連結/指引至 `HumanFinalReview.md`；Spec Review 狀態獨立保留。若 FAIL/BLOCKED 就明寫需修正；Scoped PASS 不得包裝成 Full PASS；未得到真人答覆不記人工接受。
14. 再做 cross-doc reconciliation；仍有 stale generated md、`HumanFinalReview.md` snapshot/validity 不一致或 review validity 不一致，不得 Final PASS。
15. 聊天只回短摘要並指出 `HumanReview.md`、`HumanFinalReview.md` 與 `review_00X.md`。

新增 Review 能力只加一個 check block；移除只刪該 block。Critical/Verdict/Review persistence 是 Workflow invariant，不做成可刪 block。

## Final Human Review Handoff
- 使用者完整走完 `Spec → Spec Review → Implement → Final Review` 後：
  - `HumanReview.md` = 整個流程共用的一頁摘要，分開顯示 Spec Review / Final Review 狀態。
  - `HumanFinalReview.md` = **Final Review 後專用的人工驗收文件**；要決定接受/退回時優先看它。
  - `review_00X.md` = 歷史審查證據、findings、snapshot 與完整 review record。
  `HumanFinalReview.md` 必須明確告訴人「要看哪個 requirement / flow / 舊功能 / 跨專案邊界 / regression evidence，才能確認需求真的 OK 且沒有改 A 壞 B」。完整矩陣仍留在 Architecture/TestPlan。
- `HumanReview.md` 是衍生審核頁；真實狀態仍以 `Spec.md Plan Revision`、`spec_review_00X.md`、`review_00X.md Reviewed Code Snapshot`、`TestPlan.md` 執行證據與 Git diff 為準；HumanReview 與原始證據不一致時不得宣告已完成。
- Final Reviewer **可以且必須更新所有受影響 generated Markdown** 以反映 actual facts/test/review reality，但不得修改 production/test code，也不得以改文件方式消除 implementation defect。歷史 review 原 Verdict/evidence 保留，僅追加 Current Validity/Reconciliation。
- 真正的人工接受依需求/Repo policy，需有使用者明確回覆並由對應持久文件記錄 scope、Plan Revision 與 reviewed snapshot；單純印出 `HumanReview.md` ≠ 真人驗收。

## HumanFinalReview.md Contract — Final Review 專用人工驗收頁
`ocapspec/HumanFinalReview.md` **只由 `/ocap-review` 建立/完整重建**。其他 Skill 若看到它與現況不一致，只能同步 validity/current facts 或標 `STALE`，不得假裝已重新做 Final Review。

固定保持少而精確，建議 30–70 行；高風險可更長，但不要複製完整 TestPlan/Architecture。至少包含：
1. `# Human Final Review` + `Verdict / Scope / Plan Revision / Reviewed Code Snapshot / Current Validity`。
2. `## 需求完成度`：只列這次主要 R#/Acceptance，格式 `需求 | 實際結果 | Evidence | PASS/FAIL/UNVERIFIED`。
3. `## 主要 Function / Data Flow`：從 **Actual** Architecture 抽 1 張核心 flow；明確標 direct call / HTTP / event / DB / async boundary，不能畫假的 runtime call。
4. `## A→B Regression / 穩定性`：3–7 個高價值項目，格式 `改動 A | 可能影響 B | 人要確認什麼 | Test/Evidence | 狀態`；優先 caller、shared contract、persisted state、DB migration、UI/API/Worker/Job consumer、restart/recovery。
5. `## 最重要測試與未驗證`：只列 2–6 個最能證明需求與 regression 的測試；把 live/prod/rollout 尚未驗證的內容明列 `UNVERIFIED`。
6. `## 人最後怎麼驗收`：3–7 個具體 check，不得使用「確認功能正常」這種空泛句；每項都要能指到 requirement、flow、file/function 或 test evidence。
7. `## 接受 / 退回`：提供 `接受 <Plan Revision + Reviewed Snapshot>` / `退回 <具體項目與原因>`，但未收到真人明確回覆前不得標已接受。

Validity 規則：
- 只對檔頭的 `Reviewed Code Snapshot` 有效。任何 relevant production/test/config/migration 變更後，其他 Skill 的 reconciliation 必須把 `Current Validity` 改為 `STALE`，並同步 `HumanReview.md`；不得沿用舊 Final PASS。
- 新一次 `/ocap-review` 完成後，**覆寫/完整重建同一份 `HumanFinalReview.md` 為最新 Final Review**；歷史仍由 `review_00X.md` 保存。
- Scoped Review 產生的 HumanFinalReview 必須醒目標 `SCOPED`，不可讓人誤以為整體系統 Full PASS。
- FAIL/BLOCKED 也要產生，重點改為「目前為什麼不能接受、要修什麼、修完要重新驗什麼」。

## Reviewed Snapshot（防止過期 PASS）
- 每個 Review 記錄 `Reviewed Base`、`Reviewed Code Snapshot`（Git HEAD + tracked staged/unstaged diff 與 relevant untracked files 的穩定摘要/hash；非 Git 專案則記參與審查的檔案 hash）及 `Test Evidence`（測試命令/結果/對應 snapshot）。
- `PASS` 只對本次實際審過的 snapshot 有效；之後 production/test 變更，不能直接引用舊 PASS，應重新檢查受影響區域並再 Review。
- 不能取得 snapshot 或必要 test evidence，明寫 `UNVERIFIED`；需要它才能確認通過時回 `BLOCKED`，不可憑記憶寫 PASS。

## Review Persistence
每次 Review（Full 或 Scoped）都建立下一個：
- 掃既有 `review_*.md`，最大編號 + 1，固定 3 位數，永不覆蓋/重用。
- PASS 也建立 review 檔。
- 固定結構：
  - `Status: OPEN | DONE`
  - `Verdict: PASS | FAIL | BLOCKED`
  - `Scope Type: FULL | SCOPED`
  - `Scope: <range/work item>`
  - `## Summary`
  - `## Regression / Stability Assessment`
  - `## Human Final Review Focus`（3–7 個高價值人工驗收焦點）
  - `## Review TODO`
  - `## Unverified`（有才保留）
- **只有阻擋 PASS、要求修正的 finding 才寫入 `## Review TODO`**；非阻擋建議放 `## Observations`，不使用 unchecked checkbox 或 RV#，不得使 Implement 無法結案：
  `- [ ] RV# [SEVERITY][Domain][BLOCKING]`
  並只寫必要 `Evidence / Impact / Expected / Handling hint / Tests / Mapping`。
- 沒有 blocking finding 時 `## Review TODO` 寫 `None`，非阻擋建議可放 `## Observations`。舊版未標註的 unchecked RV# 保守視為 blocking。
- 有未完成 blocking RV# 或 BLOCKED → `Status: OPEN`；無 blocking finding 的 PASS（可有 Observations）→ `DONE`。
- Finding 不綁定 implement block 名稱；Handling hint 只描述狀態。
- 舊 review 的原 Verdict/findings/snapshot/evidence 不覆寫；後續 code/test/docs evidence 使其失效時，追加 `## Current Validity / Reconciliation` 標 `STALE/SUPERSEDED`。
- 舊 review 若使用 `## TODO`，Implement 仍以 backward compatibility 消化；新 review 一律使用 `## Review TODO`。

## Global Rules
- Reviewer 獨立：不修 production/test code、不為了 PASS 弱化 finding；但必須同步 stale generated Markdown，並將文件與實際 diff/test/review reality 對齊。
- 主動找嚴重 bug，不只看 happy path。
- Severity：
  - `CRITICAL`：災難級資料/安全/核心可靠性破壞。
  - `HIGH`：主要 Requirement/contract/recovery 失效、重大 regression、實質安全漏洞、changed code 大量未測。
  - `MEDIUM`：真實 edge/coverage/reliability/maintainability 缺口。
  - `LOW`：有實際價值的小問題；純 style/偏好不列。
- CRITICAL/HIGH 一律阻擋 PASS；MEDIUM 依 impact；LOW 不單獨阻擋。
- Finding 必須有 Evidence + Impact + Expected，不得空泛 checklist。
- Review history 不覆蓋、不重編。

## Verdict
- `PASS`：這是 **Final Review PASS**，只對本次 Reviewed Code Snapshot 有效：scope 內 blocking work 收斂、Requirement/evidence 完整、主要 flow/data/state/contract 正確、changed/new behavior 有 meaningful tests、受影響既有/相鄰功能 regression 有 evidence、non-code artifacts 有適用 validation、changed code coverage/branch gap 有合理證據、無重大 regression/overdesign/spec drift，且 `HumanFinalReview.md` / `Human Final Review Focus` 已能讓人精確驗收。
- `FAIL`：存在 CRITICAL/HIGH，或其他足以阻擋驗收的 finding / 未完成工作 / 關鍵驗證不足。
- `BLOCKED`：必要環境/資料不可取得，無法可靠判定。

Scoped Review 也必須寫入新的 `review_00X.md`，並標 `Scope Type: SCOPED`。Scoped PASS 只代表指定 scope，不可包裝成整體專案 PASS。

## 輸出
```text
Final Verdict: PASS | FAIL | BLOCKED
Final Review: ocapspec/review_00X.md
Human Final Review: ocapspec/HumanFinalReview.md
Human Final Review Focus: <3–7 個焦點摘要>
Critical: N | High: N | Medium: N | Low: N
Tests/Regression: <摘要>
```
