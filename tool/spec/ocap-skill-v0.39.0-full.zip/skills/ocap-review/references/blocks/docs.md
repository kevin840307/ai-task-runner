---
block: docs
role: check
priority: 40
always: false
---

# Docs / Traceability

## Match
存在 `ocapspec/` 或 Review scope 明確包含規格/規劃文件時適用。

## Inspect
檢查**所有受影響 generated md** 與 actual diff/evidence 是否一致，並特別確認：
- `Spec.md` 是否與 user prompt/後續決策一致，R#/Acceptance 無語意漂移，`Plan Revision` 與 `Requirement Sources` 是否能支持跨 Session 回溯。
- Spec Review 與 Final Review 必須分離：HumanReview 不得把 `spec_review_00X.md` PASS 寫成 implementation PASS；最新 `review_00X.md` 必須清楚是 Final Review，並含 `Human Final Review Focus`。
- 任何 Skill 發現 stale generated md 都應 reconciliation；Review 檢查 `Spec/Architecture/TestPlan/TODO/HumanReview/spec_review_*/review_*` 的 Current Validity 是否一致。歷史 verdict/evidence 只能追加 STALE/SUPERSEDED 註記，不得被覆寫。
- `Architecture.md > Function Call & Data Flow` 是否基於真實 source/diff：入口→主要 function→跨專案同步呼叫或 event/HTTP/DB 資料交接→回傳/錯誤；不應把測試中的資料傳遞畫成真實 runtime call。
- `Architecture.md` 是否為人可讀的真實 change map；Implement 後是否保留 Planned/Est. 並補 Actual/Actual LOC/Drift，而不是覆寫規劃歷史。
- `TestPlan.md` 的 `[MUST-REVIEW]` scenarios 是否真的是最高價值代表案例；可依 change surface 是 E2E/Integration/API/CLI/migration/config/recovery/docs validation，不能因此漏掉完整 changed/new behavior/evidence。
- Implement 是否持續做 Doc Sync：actual diff/behavior 已改變時，`Spec.md / Architecture.md / TestPlan.md / TODO.md` 不得仍停在舊規劃；Architecture 應保留 Planned 並補最新 Actual/Drift/affected existing functionality。
- `HumanReview.md` 的主要呼叫／資料流圖是否從 canonical Architecture 衍生、有具體且可查證的函式與跨專案界線，規劃/實際/未查證標記正確；若呼叫鏈或資料語意有 drift 而圖未同步，依影響列 finding，不得宣告無誤。
- `HumanFinalReview.md` 是否由**本次最新 Final Review**重建，Verdict/Scope/Plan Revision/Reviewed Snapshot 與 `review_00X.md` 完全一致；Requirement 完成度、Actual Function/Data Flow、A→B Regression、重要測試、Unverified 與人工驗收項目都有 evidence。若 snapshot 已變更而仍顯示 VALID/PASS，至少 MEDIUM/HIGH finding。
- `HumanReview.md` 是否由最新 canonical docs 重建且**少而精確**：只保留關鍵決策資訊，避免重複完整 dependency/test matrices；風險/未知影響有證據或標待確認，MUST-REVIEW 不為湊數；先有一眼看懂的目的/規模/風險/介面資料變更/人工確認重點；主要 change group 能看到 Project、File/Code/Config/DB/Infra Area、預估或實際 LOC/Size、會改什麼、原本邏輯是否受影響、可能影響哪些既有功能；MUST-REVIEW scenarios 與 TestPlan 一致；高風險資訊不可因精簡被省略；不得有獨有 decision/fact。
- stable IDs/mapping、checkbox/PASS 是否真實。
- 新 `review_00X.md` 的 actionable findings 是否全部位於 `## Review TODO`；舊 `## TODO` 只作 backward compatibility。
- `## Observations` 是否和 blocking actionable SR/RV checkbox 明確分離；不能讓 PASS 被未完成低嚴重度建議誤阻擋。
- HumanReview 是否清楚區分「已決定要求」與「真正待人決策」；規劃時不能聲稱測試已通過，實作後需要有實際測試 evidence。
- review history 是否被破壞。

- HumanReview 必須在**規劃**清楚呈現 Spec Summary、Project/File/Method C/U/D、估計 LOC 與舊功能影響，以及少數最高價值 E2E 與對應 test files/methods；完整 test CRUD / methods 留在 TestPlan；**最終**則同列顯示預計 vs 實際差異、真正測試證據與最後 Code Review scope/snapshot/verdict，並提供 3 點精簡人工驗收。缺原始 evidence 不能靠衍生頁補 PASS。
- `HumanReview.md` 人工接受狀態不得由 AI 自行勾選；只有真實使用者回覆與對應 snapshot 才算核准。

## Findings
假完成、假 PASS、重大 docs/architecture drift 依 impact MEDIUM/HIGH；純文字美觀或格式偏好不列。

## Complete
人類 Review 層與 AI traceability 層都和實際 requirement/code/tests 一致。
