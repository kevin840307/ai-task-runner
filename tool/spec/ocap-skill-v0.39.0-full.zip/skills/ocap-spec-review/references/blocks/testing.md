---
block: testing
role: check
priority: 80
always: true
---

# Testing

## Match
所有 Spec Review 都適用；無 production behavior 變更可驗證 TestPlan 明確 N/A。

## Inspect
從 user prompt/Acceptance/Architecture change surface 反推 TestPlan：
- 每個 changed/new behavior 是否有 meaningful test；必須排除的狀態/輸入、舊功能不變、雙參數優先序等 relevant negative/regression tests 是否清楚列預期。
- success/branch/error/boundary/state transition 是否漏測；**每個 planned changed function/method 的既有 exception/early-return/branch 是否被盤點**，不能只列新功能 happy path；optional/跨版本契約是否把 absent、present-null、0 等**有不同語意的輸入**不小心混成同一個 default（依原需求/contract 判定，不硬造無關案例）。
- 受影響既有功能是否有 regression evidence 計畫。
- Unit / Integration / E2E 是否符合真實邊界，不只靠 mock。
- 對可量測 changed code，line/branch coverage 是否規劃接近 100%，gap 是否要求 justified exception + alternate evidence；非 code change 是否有適用 validation/evidence。
- execution ladder 是否包含 baseline →（適用時 migration/schema validation）→ targeted → regression → applicable Integration/E2E → full suite → build/lint/typecheck。DB/migration 需求是否清楚區分 pre-migration baseline 與 post-migration runtime regression，並把部署順序帶進 test setup，而不是讓新 runtime 無意間跑在舊 schema。
- 多專案時是否有每個 MODIFY project 的 local tests、每個 TEST_ONLY consumer 的 regression/contract test，以及真正跨 boundary 的 Integration/E2E；shared contract/library/schema/API 改動不可只測 producer。
- public method/function signature 或 API/DTO/schema 變更是否保留舊 caller/舊 payload/舊 invocation 相容性測試，或有明確 breaking/migration 決策。
- `[MUST-REVIEW]` 數量是否隨風險/規模合理調整（小 1–2、一般 2–4、重大 3–6），沒有為湊數挑低價值情境；不限定 E2E，可依需求使用 Integration/API contract/CLI/migration/config/recovery/docs validation，且 HumanReview 只抽這些 scenario。

- `TestPlan.md` 必須有 planned test CRUD：檔名、方法/案例、情境、預期、保護原有功能。`HumanReview.md` 只摘要重要 case 與預計新增/修改的 test file/method。
- 新/改 test case 的 code 要依 `Test Code Readability` 用語意名稱加一行就近註解/docstring；規劃時必須列為 Implement 可檢查的交付項，避免測試名稱/用途看不懂。

## Findings
關鍵 Requirement/舊功能沒有驗證計畫通常 HIGH；真實 branch/edge/coverage gap MEDIUM/HIGH。

## Complete
Requirement/Architecture change surface 有足夠測試計畫與最高價值 Human-review scenarios，或已形成 finding。
