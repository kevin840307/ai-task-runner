---
block: architecture
role: check
priority: 90
always: true
---

# Architecture

## Match
所有有 implementation planning 的 Spec Review 適用。

## Inspect
以 user prompt + Spec + Repo reality 檢查 Architecture：
- Project/component/file/function/class 是否真實存在或正確標 `PROPOSED`。
- current/proposed flow、caller、contract、state/storage 假設是否正確；`Function Call & Data Flow` 是否由真實程式入口推得、包含主要 function/資料/跨專案邊界、沒有捏造直接呼叫或忽略事件交接。
- 是否選到最小合理修改位置，能 reuse 卻另造第二套、額外 service/abstraction/framework/dependency/schema/API/config。
- Code Change Sketch 是否足以表達方向、沒有發明不存在的 API；有沒有明確最小修改位置、必須保留的原有行為與所需新舊參數優先序。
- Est. LOC / file count 是否和需求規模明顯不相稱。
- `Existing behavior affected` 是否漏掉真正可能受影響的舊功能、流程、caller、persisted behavior。
- 重大 data/recovery/concurrency/security/migration 風險是否有規劃。
- 若 `Grill Mode: AUTO`，檢查有沒有優先 reuse Repo 原有 code path/架構與既有 contract、減少改動範圍；對候選方案合理衡量相容性、可維護/可測試性、依賴與 LOC；不能只追求最少行，也不能新增無需求的 abstraction。
- 多專案時必查 Project Impact Matrix：有關聯不等於要改 code；是否正確區分 MODIFY / TEST_ONLY / READ_ONLY / UNAFFECTED。若少改一個 project 仍能完整且安全滿足需求，額外 production diff 視為 overdesign/scope expansion；反之，必要 consumer adaptation 不可為了縮 project 數而漏掉。
- 跨專案 contract 是否列 producer/consumer、目前與新 contract、相容策略、主要 caller regression、部署/rollout 順序（適用時）。尤其 public method signature/API response/DTO/schema 不能只看 producer compile/test。

另外檢查 `HumanReview.md`：
- `一眼看懂` 是否能快速看出目的、改動規模、風險、API/DB/data/config 變更與最需要人工確認的事項。
- 主要 Function Call / Data Flow 圖是否清楚標出**入口、實際函式呼叫、主要資料傳遞與跨專案邊界、結果/重要錯誤**；箭頭和 Architecture/Repo 一致，且不複製完整架構圖造成閱讀負擔。
- 每個主要 Project 的 C/U/D file change (含 code area/method) 是否看得出 Project、File/Code/Config/DB/Infra Area、預估 LOC/Size（適用時）、會改什麼、原本邏輯影響、可能影響哪些舊功能。多專案 HumanReview 還要能一眼區分 MODIFY、TEST_ONLY 與保護不動的相關 Project。
- 高風險 contract/data/security/recovery change 不得因精簡而被省略。
- test-only/機械式低風險變更可以彙總，不應淹沒主要變更。
- 與 canonical Architecture 一致，不得有獨有事實。
- 風險分級須能指出現有功能/契約/資料上的理由；缺 evidence 要寫待確認，不可直接標低風險。
- 文字必須短、白話、可快速掃讀；避免同一事實在多區重複、全量測試清單/contract matrix 塞滿人類摘要；只寫「調整 Service / 修改 UI / 優化流程」而沒有具體影響也視為不足。

## Findings
錯誤/不可行架構、重大舊功能 impact 漏失、危險 data/contract 設計通常 HIGH；overdesign/局部 impact 漏失依程度 MEDIUM/HIGH。

## Complete
Architecture 可由現有 Repo 安全落地、scope/複雜度合理、舊功能 impact 已辨識，或已形成 finding。
