---
name: ocap-spec-review
description: Pre-implementation Spec Review. Validate the exact user prompt and decisions against repository reality and OCAP planning, reconcile stale generated Markdown to current facts, and persist independent SR# findings without modifying production code.
---

# ocap-spec-review

直接輸入 `/ocap-spec-review`。這是 **Pre-Implementation Spec Review**：只判斷規劃是否正確、完整、可安全實作；**不做 Final Review、也不修改 production/test code**。若 generated md 與 Repo/Prompt 現況不同，允許並要求依 `Global Generated-MD Reconciliation` 同步文件，但不能為了 PASS 改寫使用者需求。

## Runtime Context
所有 checks 必須同時考慮：
- **使用者輸入的 prompt**：本次需求、原始要求、後續明確補充/決策、限制與 scope。若內容衝突，以較新的明確使用者決策為準。
- Repo/workspace/instructions/relevant source/tests/contracts/storage。
- canonical planning docs：`Spec.md / Architecture.md / TestPlan.md / TODO.md`，包含 `Spec.md` 的 `Plan Revision` 和 `Requirement Sources`。
- `HumanReview.md` derived view；檢查是否**少而精確**：只顯示人需要決定的 scope/風險/主要改動/少數高價值測試/最終 evidence，不複製完整 AI 矩陣。
- `Grill Mode` 與 `Spec.md` 裡的 `AI_SELECTED / ASSUMPTION / BLOCKING_DECISION`（如有），以及其 Repo evidence、替代方案與受影響既有功能。
- 既有 `spec_review_*.md` / implementation review history。

**禁止只 Review 產出的文件而忽略 user prompt。** Prompt/後續決策是 Requirement truth 的第一級 evidence。
如原始 prompt 已不可取得，要明確區分「有原文證據」與「只有 Spec 來源摘要」；重要需求/決策無法可靠核對就 `BLOCKED`，不可把來源摘要當成原 prompt 已驗證。

## Global Generated-MD Reconciliation（所有 Skill 共用）
任何 OCAP Skill 執行時，只要取得的新 prompt、Repo、diff、test、coverage、review、runtime evidence 顯示**已產生的 Markdown 與現況不一致**，就必須在該次 invocation 內同步所有受影響的 generated md；不能因「這不是本 Skill 原本負責的文件」而留下 stale 狀態。

### 必須掃描的 generated md
至少包含存在的：
- `ocapspec/Spec.md`
- `ocapspec/Architecture.md`
- `ocapspec/TestPlan.md`
- `ocapspec/TODO.md`
- `ocapspec/HumanReview.md`
- `ocapspec/HumanFinalReview.md`（若已產生；僅 Final Review 建立，其他 Skill 只同步/標 STALE）
- `ocapspec/spec_review_*.md`
- `ocapspec/review_*.md`
- 其他由 OCAP block/extension 產生且與本次 evidence 有關的 `ocapspec/**/*.md`

### Reconcile 規則
1. **Current-state docs 直接同步現況**：檔案/Project/Function Call & Data Flow、Actual LOC、contract/data/state、test cases、coverage/evidence、TODO 狀態、風險、未驗證項等有新事實就更新。
2. **Requirement truth 不可被 implementation 倒推改寫**：若 actual code 與 user prompt/已確認 Requirement 不同，文件要同時保留「要求」與「Actual Drift」，標 `NEED_REPLAN/FAIL/BLOCKED`（依 Skill），不能把 Spec 改成配合錯誤實作來製造一致。
3. **Material planning change** 依 Planning Baseline 增加 `Plan Revision`；任何綁舊 Revision 的 Spec Review PASS 都標 `STALE/SUPERSEDED`，必須重新 Spec Review。
4. **Review history 保留原始證據**：`spec_review_00X.md` / `review_00X.md` 的原 Verdict、finding、snapshot、evidence 不覆寫、不刪除。後來 evidence 改變有效性時，可追加/更新 `## Current Validity / Reconciliation`，標 `VALID / STALE / SUPERSEDED`、原因與替代的最新 review。
5. **HumanReview 永遠重建為最新人工入口**：從 canonical docs + 最新有效 Review + actual evidence 衍生；不得保留已知 stale flow、檔案清單、測試結果或 Review 狀態。
6. 同一 invocation 在輸出 PASS/READY/CONVERGED/SCOPE_COMPLETE 前，必須再次做 cross-doc consistency check；仍有已知 stale generated md 就不能宣告完成。
7. Auto-sync 只更新 Markdown/衍生狀態，不代表 Reviewer 可以修改 production/test code。只有 `/ocap-implement` 依 work item 修改交付內容；Spec/Final Review 仍保持 implementation independence。

## Spec Review vs Final Review
- `spec_review_00X.md` 只屬於 **Spec Review**：驗 Requirement/Acceptance、Architecture、Scope、TestPlan、HumanReview planning view。
- 它不判斷 actual implementation 是否穩定，也不能替代 `/ocap-review` 的 Final Review。
- HumanReview 必須把 Spec Review 狀態與 Final Review 狀態分開；沒有 Final Review 就寫 `NOT_RUN`。
- `HumanFinalReview.md` 不是 Spec Review 產物；若不存在不建立。若已存在但 Plan Revision / code snapshot 已失效，只同步 `Current Validity: STALE` 與 HumanReview 狀態，等下次 `/ocap-review` 重建。

## Invocation Scope
- 無明確 scope → `FULL` Spec Review，作為 Implementation 前的 planning gate。
- user 明確指定 R#/文件/區域 → `SCOPED` Review；Scoped PASS 只代表該 scope，不代表整體 plan ready。

## Workflow
1. Discover：掃 `references/blocks/*.md`。
2. Validate：每個 check block 必須有唯一 `block`、`role: check`、整數 priority、boolean always，以及 `Match / Inspect / Findings / Complete`。
3. Select：`always: true` 每次都跑；`always: false` 僅 Match 成立才跑。
4. Run：priority 高到低；每個 check 都必須能引用 user prompt/decision、Repo 或 canonical doc evidence。
5. Aggregate：同 root cause 合併，不因不同 block 重複 finding。
6. Normalize severity。
7. Generated-MD Reconciliation：先將所有受影響 generated md 同步到目前 prompt/repo facts；若 reconciliation 造成 material plan change，增加 `Plan Revision`，本輪不得沿用舊 PASS。
8. Determine Verdict：以**同步後的 current Plan Revision**判斷；若本輪發現的 blocking planning issue 需要實質改 plan，不得因 Reviewer 自行補文字就自動消除 finding，應 FAIL/BLOCKED 並要求重新 Spec Review。
9. Persist：建立下一個 `ocapspec/spec_review_00X.md`，並在 HumanReview 的 `Spec Review` 欄位更新本次狀態；Final Review 欄位不碰成 PASS。
10. 再做一次 generated-md consistency check；仍有 stale docs 不得 PASS。
11. 聊天只回短摘要。

## Review Persistence
每次 Full/Scoped 都建立下一個 `spec_review_00X.md`：
- 最大既有編號 + 1，固定 3 位數，永不覆蓋/重用。
- 固定：
  - `Status: OPEN | DONE`
  - `Verdict: PASS | FAIL | BLOCKED`
  - `Scope Type: FULL | SCOPED`
  - `Scope: <scope>`
  - `Plan Revision: <Spec.md 的確切正整數>`（審核當下的 Planning Baseline；缺失/無法確認則不得宣告有效的 PASS）
  - `Prompt Evidence: ORIGINAL | SOURCE_SUMMARY_ONLY | INCOMPLETE`（揭露 Review 的實際來源）
  - `## Summary`
  - `## Spec Review TODO`
  - `## Unverified`（有才留）
- **會阻擋通過、必須由 Spec Grill 修正**的 finding 才是 actionable：`- [ ] SR# [SEVERITY][Domain][BLOCKING]`，位於 `## Spec Review TODO`。
- **不阻擋通過的建議**放 `## Observations`，不使用 unchecked checkbox / SR# / `Actionable Work`；附 evidence/影響但不能被 Implement 誤撿成工作。
- `PASS` 不得含未完成的 blocking SR#；`FAIL` 才有未完成 blocking work。LOW/MEDIUM 若是阻擋，也必須明示 `[BLOCKING]` 及原因。舊版沒有標記的 unchecked SR# 保守視為 blocking，避免漏掉真實問題。
- finding 只寫必要 `Evidence / Impact / Expected / Handling hint / Mapping`。
- **Evidence 必須優先指出 user prompt/decision、Repo reality 或 canonical doc 中的具體矛盾/缺口。**
- 無 blocking finding：`## Spec Review TODO` 寫 `None`；若有 nonblocking 建議，保留 `## Observations`。
- 有未完成 blocking finding 或 BLOCKED → `Status: OPEN`；沒有 blocking finding 的 PASS（可以有 Observations）→ `DONE`。
- SR# 只由 `/ocap-spec-grill` 解決；不要綁定 implementation block。
- 舊 review 的原 Verdict/findings/evidence 不覆寫；若後續 Plan Revision 或 evidence 使其失效，依全域 reconciliation 追加 `## Current Validity / Reconciliation` 標 `STALE/SUPERSEDED`。
- PASS 永遠綁定其 `Plan Revision` 與 Scope：後續若 materially replan，必須重新 Review 才能視為新的有效 PASS；Implement 的 Actual/LOC/checkbox/evidence writeback 不會自動使 PASS 失效。

## Severity
- `CRITICAL`：規劃若照做可能造成災難級 data/security/core reliability 破壞。
- `HIGH`：主要 user requirement/acceptance 遺漏或誤解、重大 contract/data/architecture 錯誤、計畫不可安全實作、關鍵測試缺失。
- `MEDIUM`：真實 edge/impact/coverage/traceability/feasibility 缺口，可能造成返工或 regression。
- `LOW`：有實際價值的小問題；純 style/偏好不列。

CRITICAL/HIGH 阻擋 PASS；MEDIUM 視 impact；LOW 不單獨阻擋。

## Global Rules
- Reviewer 獨立於 implementation：不改 production/test code；但若 generated md 與可驗證現況不一致，**必須**同步所有受影響 Markdown。文件同步不能用來消除自己剛發現的 blocking planning defect 或改寫 user requirement。
- user prompt + 後續明確決策必須逐項納入 Review，不得只相信 Spec Summary 或 TODO。
- 主動找漏需求、偷偷改 scope、錯誤架構假設、漏掉的 existing behavior impact、測試盲點、overdesign 與不可實作計畫。
- `AUTO` 決策不能因「AI 已選」就免審：獨立檢查是否存在更小且安全的 Repo-native 方案、是否不必要抽象/依賴/跨專案修改、是否把 LOC 少凌駕於可維護性/相容性、是否隱藏原功能回歸面。
- 若仍有未解 `BLOCKING_DECISION` 或關鍵假設未被驗證，不得 PASS；明確區分 `AI_SELECTED` 與使用者已確認決策。
- HumanReview 的「要人確認」不能重複早已決定的 prompt 條件；必須讓人知道**哪個選擇仍未決**、可能傷到哪個原功能、測試尚未跑還是已跑。人能 1–2 分鐘掃過並決定是否要看 diff。
- HumanReview 必須先給 Spec Summary/風險，接著依專案列 C/U/D 檔案/方法/預估 LOC/既有功能影響、重要 E2E 與預計新增/修改的 test files/test methods；僅寫「調整 Service」或漏掉 test change 不可 PASS。規劃期的最終結果明寫 `未執行`，不能假裝 Code Review 或測試 PASS。
- Finding 必須 Evidence + Impact + Expected；禁止空泛 checklist。
- `HumanReview.md` 的風險與原功能影響需有 canonical evidence；無法確認要明寫待確認，高風險不可精簡隱藏。
- 不為了符合固定數量而強迫生出多餘 Must-Review 情境。
- `HumanReview.md` 只是 derived view；若與 canonical docs 不同，報 drift，不把 HumanReview 當 source of truth。
- HumanReview 是給人看的 review surface：短句、表格與白話；重要 test case 讓人看得出「測什麼/預期/保護什麼」，規劃與最終結果用同一份衍生文件、不能把 human acceptance 當成 AI 自動完成。
- 不 commit/push/release，除非使用者另外明確要求。

## Verdict
- `PASS`：所有 blocking SR# 已解決；`Plan Revision` 有效且記錄來源核對範圍；`AUTO` 選擇有 Repo/Prompt evidence、無未解重大 blocker、沒有假造使用者批准；scope 內 user prompt/決策被完整正確規劃；Architecture 與 Repo reality/最小改動一致；測試覆蓋計畫完整；cross-doc mapping 收斂；HumanReview derived view 正確且容易掃讀，主要 code change 的位置/LOC/內容/原邏輯影響/舊功能影響都清楚；無 blocking finding。
- `FAIL`：有 blocking finding、漏需求、重大 drift、錯誤 architecture/testing/traceability 或未收斂 planning work。
- `BLOCKED`：必要 prompt/repo/context 無法取得，無法可靠判斷。

Full PASS 才代表 plan 可進入 Human Review / Implementation；Scoped PASS 不代表整體 ready。

## Output
```text
Verdict: PASS | FAIL | BLOCKED
Review: ocapspec/spec_review_00X.md
Human Review: ocapspec/HumanReview.md
Critical: N | High: N | Medium: N | Low: N
```
