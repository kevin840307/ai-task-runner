---
block: prompt-requirements
role: check
priority: 100
always: true
---

# Prompt / Requirements

## Match
所有 Spec Review 都適用。

## Inspect
直接讀 user prompt 與後續明確決策，逐一對照 Spec：
- Goal / requested behavior 有沒有漏掉或被改語意。
- scope / non-goals / restrictions 是否正確。
- protected existing behavior 是否有被忽略。
- Acceptance 是否可觀察、可驗證且足以證明 prompt。
- generated plan 是否偷偷新增 user 未要求的產品行為。
- HumanReview Requirement Summary 是否只是正確衍生，不遺漏最重要的 prompt intent。
- `AUTO` 下的 `AI_SELECTED` 是否只是技術實作選擇，沒有把未經授權的需求/權限/資料語意改動冒充 `USER_CONFIRMED`；`BLOCKING_DECISION` 是否如實保留而非被默默消除。

不要用「Spec 已經這樣寫」當 evidence；要回到 prompt/decision truth。

## Findings
主要需求錯誤/遺漏通常 HIGH；局部 edge/摘要 drift 依 impact MEDIUM/HIGH。

## Complete
scope 內 user prompt/明確決策均有正確 Requirement/Acceptance 或 finding。
