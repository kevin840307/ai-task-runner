---
block: fix
priority: 90
fallback: false
---

# FIX

## Match
defect 已確認、expected behavior 明確、root cause 已足夠明確可安全修改。來源可為 user prompt、review finding、failing test 或其他 evidence。

## Work Discovery
優先 user 指定 confirmed defect；否則找 unchecked review finding 或其他已確認 defect。Review 依 CRITICAL > HIGH > MEDIUM > LOW；同級先舊後新。

## Execute
重新重現 → 最小 root-cause fix → 補能防同 root cause 回歸的 meaningful regression test。若 root cause 其實未明，回寫 evidence 後 `REROUTE`，不猜修法。

## Writeback
- Review source：回原 RV# 寫 `Resolution/Evidence`，Global testing rules 與必要 regression 都成立才勾；該 review 全部 actionable finding 完成可 `Status: DONE`，保留原 Verdict。
- 其他 source：回寫原 source；遵守 `Implementation Drift & Doc Sync`，root-cause fix 若讓實際架構/測試/TODO/affected existing functionality 與原規劃不同，立即同步 canonical docs，必要時重建 HumanReview；semantic drift 則 `NEED_REPLAN`。
- 同一 defect 不複製到第二個 queue。

- regression testcase 也必須有清楚的 method 名稱與緊貼該方法的簡短 comment/docstring，方便之後的人一眼知道防止哪個 bug；同步至 TestPlan 與 HumanReview 的測試清單。

## Complete
root-cause fix、Global testing rules、必要 regression/writeback 都完成後 `REROUTE`。
