---
block: dev
priority: 20
fallback: true
---

# DEV

## Match
正常規劃 implementation、`ocapspec/TODO.md` 未完成 T#，或 user prompt 指定的正常開發/小型 production work。

## Work Discovery
1. 優先 user 指定 T#/明確 dev work。
2. 否則找 dependency 已滿足的下一個 unchecked T#。
3. user prompt 是 production 小修但沒有 work source 時，可建立 transient candidate；若為維持 traceability 必須落盤，先補到最合適的既有 TODO，再執行。
4. 完成/SUPERSEDED/尚未解除 BLOCKED 不選。

## Execute
核對 Requirement/Acceptance/protected behavior/actual code path → 找最小修改位置 → 實作。屬於本 work item 的普通 defect 直接在同 item 修，不另外製造 queue。

## Writeback
遵守 SKILL 的 `Implementation Drift & Doc Sync`。每次 actual implementation 與規劃不一致時立即同步真正受影響的 `Spec.md / Architecture.md / TestPlan.md / TODO.md`，必要時重建 `HumanReview.md`；不要等整個 task 結束才補。Transient work 若不需要持久追蹤，不硬造文件；需要 traceability 才落盤。若差異改變 confirmed semantics → `NEED_REPLAN`。

- 每個本次新增/修改的 Test Case 都要在 test source 以語意名稱與一行貼近程式碼的簡短 comment/docstring 表明測試情境、預期和保護功能；隨著 diff 更新 TestPlan test file/method map 與 HumanReview。

## Complete
本 work item 的行為、Global testing rules、regression、必要 docs/evidence 都成立才完成；持久 work item 才勾選。完成回 `REROUTE`。
