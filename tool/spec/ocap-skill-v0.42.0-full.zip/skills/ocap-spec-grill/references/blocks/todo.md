---
block: todo
priority: 10
always: true
---

# TODO

## Match
規劃需要交給 implement 執行時適用。

## Analyze
依 Requirements、Architecture、TestPlan 與已解決 SR# 建立最小可執行工作；可涵蓋 code、DB、config、infra、migration、docs/contract 等實際交付，不拆微步驟。

## Grill
- `INTERACTIVE`：只有 dependency / ownership 無法從 Repo 或其他 Core 推導時才問。
- `AUTO`：優先用 Repo 既有 ownership/dependency pattern，保留最少必要 T#；`BLOCKING_DECISION` 的工作不得被寫成可執行/已核准的 T#，不可用 checkbox 假裝決策已解。

## Writeback
更新 `ocapspec/TODO.md`：
- stable `T#` checkbox。
- owning project / dependency。
- 對應必要 R#/F#/test mapping。
- completion evidence；TestPlan 的 planned test file/method 要在對應 TODO 的完成證據中能找到，避免只改 production code 沒補測試。
- 保留 completed/blocked/superseded 狀態。
- 最後包含 regression / full validation / independent implementation review gate。

不要複製 Architecture code sketch 或 TestPlan testcase；用 stable ID mapping 指回。
`SR#` 是 planning finding，不直接變成 implement T#；先修正 canonical plan，只有確實新增/改變 implementation work 時才更新相應 T#。

## Complete
所有 canonical planning obligation 可由 TODO 驅動，無 orphan Requirement/Architecture/Test obligation。
