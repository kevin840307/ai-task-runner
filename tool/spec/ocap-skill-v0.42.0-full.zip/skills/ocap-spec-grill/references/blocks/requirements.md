---
block: requirements
priority: 100
always: true
---

# Requirements

## Match
所有規劃都適用。

## Analyze
以 user prompt + 後續明確決策為第一來源，釐清 Goal、目前/預期行為、Scope/Non-goals、protected behavior、R#/Acceptance、已確認決策與必要假設。避免把實作細節當需求。

處理 Requirements 類 SR# 時，必須回到原 prompt/決策驗證，不可只照舊 Spec 修字。

## Grill
- `INTERACTIVE`：只問會改變產品行為、Acceptance、scope 或相容性的缺口。
- `AUTO`：先依 prompt/Repo/已確認決策判斷。能保守選擇且不偷改需求的技術細節，使用 `AI_SELECTED` 記錄；必須由使用者明確選擇的相互矛盾產品行為、權限或資料語意則記 `BLOCKING_DECISION`，不捏造 user agreement。

## Writeback
更新 `ocapspec/Spec.md`，作為 canonical requirements source。建議包含：
- `## Planning Baseline`（`Plan Revision` 與 `Grill Mode: INTERACTIVE | AUTO`、選擇原因；material planning change 才升版）
- `## Requirement Sources`（逐項保存原 prompt/決策關鍵條件與可用來源；不複製 secrets、不捏造原文）
- `## Goal`
- `## Scope / Non-goals`
- `## Requirements`（stable R#）
- `## Acceptance`（對重要行為寫可觀察的輸入/條件→預期結果；保護既有功能時寫負面/不變條件；不可偷偷增加新需求）
- `## Protected Behavior`（原始 API/參數、舊 caller、排序、狀態、資料等適用且可查證項目；未知時標待查）
- `## Decisions / Assumptions`（`AUTO` 的每個重要自行選擇標 `AI_SELECTED`，包含 rationale、影響、替代方案、驗證方式；重大未決標 `BLOCKING_DECISION`，不要視為已核准）

若多輪 Grill 改動已確認需求/規劃，須依 workflow 更新 Plan Revision 並保留之前重要決策的可追溯性。
不要為了人類 Review 在 Spec 另外維護一份摘要；人類摘要由 Workflow 衍生到 `HumanReview.md`。
不要重複 Architecture/TestPlan/TODO 細節。

## Complete
user prompt/已確認決策均能映射到 scope 內 Requirement/Acceptance；protected behavior 與 Non-goals 清楚；`AUTO` 選擇有 evidence，沒有把 `BLOCKING_DECISION` 當成完成；Requirements 類 SR# 已有 resolution 或明確 blocker。
