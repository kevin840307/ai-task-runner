---
name: ocap-spec-grill
description: Dual-mode OCAP planning for interactive conversation and non-interactive Agent CLI. Auto Grill chooses the smallest maintainable, compatible and evidence-backed approach without unsafe assumptions; preserves prompt traceability and regenerates HumanReview.md.
---

# ocap-spec-grill

直接輸入 `/ocap-spec-grill` 即可。`SKILL.md` 只負責 Workflow + Global Rules；規劃細節與 canonical 文件由 `references/blocks/*.md` 決定。

## Runtime Context
所有積木共享：
- 本次 user prompt，以及同一需求後續明確補充/決策；後來的明確決策可取代較早衝突內容。
- Repository / workspace / instructions / relevant code/tests/contracts/storage。
- canonical planning docs：`Spec.md / Architecture.md / TestPlan.md / TODO.md`。
- `HumanReview.md`（derived view，不是 source of truth）。
- `spec_review_*.md`、既有 implementation review history、完成歷史。
- 本輪新 evidence / 使用者回答。

有新 prompt 必須納入所有積木；已有 `ocapspec/` 且無新 prompt 時直接延續，不要求重述需求。

## Grill Mode Selection
共用原有 `/ocap-spec-grill`，不新增 Skill 或 CLI 指令：
- `INTERACTIVE`（預設，確實可持續收取 user 回答的聊天環境）：沿用最多 3 題/輪的 Grill。
- `AUTO`：使用者指定 `--auto` / `auto grill` /「自行決定、不需反問」，或**確實屬於不能等待回覆的 Agent CLI、腳本、CI、無人值守 pipeline** 時，自動選用。
- 明確知道沒有可用的互動回覆通道，就算使用者沒寫 `--auto` 也必須用 `AUTO`；**不可呼叫互動提問工具或等待 stdin/人類回答**。
- 不可只因看到「CLI」字樣，就推斷聊天中的使用者無法互動；模式以實際執行情境、明確參數/指示為準。
- 已明確要求互動但環境確實不能互動時，不能假裝可互動；先遵守不詢問規則，只在有證據可安全決策時繼續，否則 `BLOCKED`。
- 每次在 `Spec.md` 的 `## Planning Baseline` 記錄 `Grill Mode: INTERACTIVE | AUTO` 和簡短選用原因；切換模式本身不構成 material planning change，不因此升 `Plan Revision`。

## Auto Grill Decision Policy
`AUTO` 是**自行做保守的技術規劃決策**，不是自行新增或修改使用者需求。
1. 先對照 prompt/已確認決策、Repo 實況、既有 caller/contract/data/behavior、tests。能從事實推得的答案直接用證據解決，不詢問。
2. 針對剩下的技術選擇只比較少數真正可行方案；必要時列 1–3 個候選，不必湊數。
3. 按以下**先後次序**判斷，絕不是單純 LOC 最小：
   - **正確與相容性**：符合 Acceptance；保護既有 behavior、API/DB/資料、授權、安全、恢復語意；不宣稱未知的影響為 0。
   - **最小影響**：優先沿用既有 code path、service、library、schema、project convention；減少跨專案改動和 regression surface。
   - **可維護與可驗證**：簡單、可讀、易測、有明確責任；避免硬塞一個 function、code golf、隱藏副作用。
   - **避免過度設計**：沒有現在需求的理由，不新增 framework/service/layer/dependency/schema、泛用 abstraction 或順手重構。
   - **改動量**：在上述條件相當時，優先檔案/LOC 少、部署或回滾簡單的方案；LOC 只能合理估計，不偽造數據。
4. 如果無法做到「完全不影響」原功能，選**滿足需求的最小必要影響**方案，具體列明既有功能/呼叫者、regression 測試與減緩方式；不能因偏好少行程式碼犧牲正確性。
5. 每個有實質影響的自行決策在 `Spec.md` 的 `## Decisions / Assumptions` 以 `AI_SELECTED` 標記，寫一個精簡記錄：`選擇 | 依據(Repo/prompt) | 被排除的可行替代方案/原因(如有) | 原功能影響/風險 | 如何驗證`。不得寫成 `USER_CONFIRMED`，也不得把臆測稱為已查證。
6. 非阻擋性的資訊不完整，可作**明確標示、可逆且保守**的 `ASSUMPTION`，附可驗證條件；不可把未確認的重大假設轉成已確認需求。
7. 下列屬**不可安全自行決定**的阻擋情境：需求/Acceptance 互相矛盾且 Repo 無法消歧、可能破壞既有 API/資料/授權與安全邊界、不可逆 migration/刪除、重大 state/recovery 語意改變、需要新增使用者未授權的產品行為且無可保守避開方案。盡可能完成可確定的規劃，記錄 `BLOCKING_DECISION`、需使用者判斷的選項及影響；回 `BLOCKED`，**不宣告 `CONVERGED`、不把該項變成可執行 TODO**。
8. 所有 Core/Extension Blocks 共用相同模式與決策優先序；Auto 不逐輪 Grill，不對使用者發問，分析後寫回 canonical docs、產出 HumanReview，再自我驗證。可行且沒有 blocker 才 `CONVERGED`。


## Workflow
1. Discover：掃 `references/blocks/*.md`。
2. Validate：
   - Required Core Blocks：`requirements`、`architecture`、`testing`、`todo`。
   - 缺任一 Core Block、重複 block、frontmatter/type 不合法或缺必要 Section → `BLOCK_CONFIG_ERROR`。
   - 每個 block 必須有唯一 `block`、整數 `priority`、boolean `always`，以及 `Match / Analyze / Grill / Writeback / Complete`。
3. Spec Review Intake：掃 `spec_review_*.md`；未完成的 blocking `SR#`（舊版未標註 blocking 的 SR# 保守當 blocking；`SUPERSEDED/NON_ACTIONABLE` 除外）才是 planning work。`## Observations` 非待辦，不阻擋 `CONVERGED`。
4. Select：Core Blocks 永遠參與；Extension Blocks 依 `always/Match`。priority 高到低。
5. Mode：依 `Grill Mode Selection` 判定 `INTERACTIVE` 或 `AUTO`；所有積木共用同一模式。
6. Analyze：所有適用 block 讀同一 Runtime Context，包含 user prompt 與 SR# evidence。
7. Decide / Grill：
   - `INTERACTIVE`：彙整、去重高影響未決問題；每輪最多 3 題，只問會改變需求、架構、相容性、資料、錯誤恢復或驗收的問題；收到回答後更新 Context 並重新分析。
   - `AUTO`：不向人提問；依 `Auto Grill Decision Policy` 自行選最小、安全、可維護的方案；無法安全決定時記 `BLOCKING_DECISION`，回 `BLOCKED`。
8. Writeback：各 block 更新 canonical 文件與選擇依據；若正在處理 SR#，在原 `spec_review_00X.md` 的 SR# 寫 `Resolution/Evidence`，**只有真正處理完才勾選**，保留原 Verdict/history。`AUTO` 如有 blocker，可保存非阻擋部分與理由，但不可產生可直接執行的假定結論。
9. Generated-MD Reconciliation：依全域規則同步所有受影響的 `ocapspec/**/*.md`；若本次 material replan 使舊 Spec Review 過期，標記舊 review `STALE/SUPERSEDED`，不覆寫原 Verdict。
10. Regenerate Human Review：依 `HumanReview.md Contract` 從最新 **planning canonical docs + Spec Review validity** 完整重建 `ocapspec/HumanReview.md`。它只呈現「預計怎麼改／要測什麼／Spec Review 是否通過」，**不放 implementation actual、Final Review、snapshot 或實際測試結果**；那些只放 `HumanFinalReview.md`。
11. 重新跑 blocks + cross-doc reconciliation；所有適用 blocks Complete、文件無已知 stale、沒有未解重大決策與 blocking SR# 才 `CONVERGED`。

## Planning Baseline & Prompt Provenance
- `Spec.md` 固定有 `## Planning Baseline`，包含 `Plan Revision: <positive integer>`；新需求首次建檔用 `1`，延續既有規劃要保留並單調遞增，不可重設/覆蓋歷史。
- 只在**material planning change** 增加 Revision：user 新需求或明確決策改變 Requirement/Acceptance/保護行為、Planned Architecture/Contract、預期 Validation 設計或 TODO 工作範圍。
- 格式整理、修正無語意錯字、TODO checkbox/evidence、實作後的 Actual/LOC/Drift、測試執行結果、重建 HumanReview **不增加 Revision**。Implement 不得透過修改 Planning Baseline 迴避 Spec Review。
- `Spec.md` 同時保留精簡的 `## Requirement Sources`：對每個主要 R# 記「原始 prompt 的關鍵要求、後續明確決策、重要禁止/不變條件」及可取得的來源線索。來源摘要不是原 prompt 的替代品，不要捏造未曾說過的要求，也不要複製金鑰/密碼等 secrets。
- Spec Review 應優先比對**實際可取得的 user prompt/決策**。跨 Session 找不到原文時，必須揭露可驗證範圍；若缺失會影響重要需求真偽，應 `BLOCKED`，不可假裝完整比對。
- `HumanReview.md` 只根據 canonical facts 產生，不另設版本或獨立決策；對 AI 選定但尚未驗證的方案須保留 `AI_SELECTED / 待驗證` 標示，不能當使用者已核准。

## 通用 Change Surface
OCAP 預設用於軟體/技術交付，但不只限一般 application code。以下都可以套用：
- runtime/application code、library/SDK、CLI/script。
- API/contract、DB/schema/migration、persisted data。
- config、YAML、CI/CD、build/deploy、infra/IaC。
- worker/background job、observability、security/reliability behavior。
- docs-only / contract-only change。

規則：
- 沒有 runtime/code 變更時，Architecture/TestPlan 可以精簡或標 N/A，不硬造 code sketch、coverage 或 E2E。
- docs/config/infra/migration 類需求仍要回答：改什麼、可能影響什麼、如何驗證。
- 只有真的可量測 code coverage 時才要求 line/branch coverage；其他類型改用最接近真實風險的 validation/evidence。

## Core vs Extension
- `requirements / architecture / testing / todo` 是 Planning Core Blocks。
- migration/security/performance 等額外規劃能力使用 Extension Block。
- 新增/移除 Extension 不需改主 Workflow。
- Extension 不得要求另一個特定 Extension 一定存在；可依 Core 產物工作。

### Persistent Work Contract
Extension 若留下 Implement 可執行 work：
- 必須放 `## Actionable Work`（含子 section）。
- stable ID，例如 `M1 / SEC2 / PERF3`：`- [ ] M1 ...`。
- Core `TODO.md` 使用 `## TODO`；implementation Review 使用 `## Review TODO`。
- **Spec Review 使用 `## Spec Review TODO`，只由 `/ocap-spec-grill` 消化，不屬於 implementation work。**
- 不得另創可執行 queue heading。

## Global Generated-MD Reconciliation（所有 Skill 共用）
任何 OCAP Skill 執行時，只要取得的新 prompt、Repo、diff、test、coverage、review、runtime evidence 顯示**已產生的 Markdown 與現況不一致**，就必須在該次 invocation 內同步所有受影響的 generated md；不能因「這不是本 Skill 原本負責的文件」而留下 stale 狀態。

### 必須掃描的 generated md
至少包含存在的：
- `ocapspec/Spec.md`
- `ocapspec/Architecture.md`
- `ocapspec/TestPlan.md`
- `ocapspec/TODO.md`
- `ocapspec/HumanReview.md`
- `ocapspec/HumanFinalReview.md`（若已產生；僅 Final Review 建立，其他 Skill 只同步/標 STALE）
- `ocapspec/spec_review_*.md`
- `ocapspec/review_*.md`
- 其他由 OCAP block/extension 產生且與本次 evidence 有關的 `ocapspec/**/*.md`

### Reconcile 規則
1. **Current-state docs 直接同步現況**：檔案/Project/Function Call & Data Flow、Actual LOC、contract/data/state、test cases、coverage/evidence、TODO 狀態、風險、未驗證項等有新事實就更新。
2. **Requirement truth 不可被 implementation 倒推改寫**：若 actual code 與 user prompt/已確認 Requirement 不同，文件要同時保留「要求」與「Actual Drift」，標 `NEED_REPLAN/FAIL/BLOCKED`（依 Skill），不能把 Spec 改成配合錯誤實作來製造一致。
3. **Material planning change** 依 Planning Baseline 增加 `Plan Revision`；任何綁舊 Revision 的 Spec Review PASS 都標 `STALE/SUPERSEDED`，必須重新 Spec Review。
4. **Review history 保留原始證據**：`spec_review_00X.md` / `review_00X.md` 的原 Verdict、finding、snapshot、evidence 不覆寫、不刪除。後來 evidence 改變有效性時，可追加/更新 `## Current Validity / Reconciliation`，標 `VALID / STALE / SUPERSEDED`、原因與替代的最新 review。
5. **HumanReview 是規劃/Spec Review 專用**：只由 `/ocap-spec-grill` 或 `/ocap-spec-review` 依目前 Plan Revision 重建；`/ocap-implement` 與 `/ocap-review` 不把 actual diff、實際 LOC、Final Review、snapshot 或測試結果寫回 HumanReview。若 implementation 證明需要 material replan，回到 Spec Grill 更新計畫後再重建 HumanReview。
6. 同一 invocation 在輸出 PASS/READY/CONVERGED/SCOPE_COMPLETE 前，必須再次做 cross-doc consistency check；仍有已知 stale generated md 就不能宣告完成。
7. Auto-sync 只更新 Markdown/衍生狀態，不代表 Reviewer 可以修改 production/test code。只有 `/ocap-implement` 依 work item 修改交付內容；Spec/Final Review 仍保持 implementation independence。

## HumanReview.md Contract — 規劃要讓人一眼看懂，也要看得出怎麼改
`ocapspec/HumanReview.md` 是**規劃 / Spec Review 專用的人類文件**。它回答「這次要做什麼、預計改哪裡、怎麼改、會不會動到舊功能、準備測哪些情境」。實作後的 actual diff / actual LOC / 真正測試結果 / Final Review 一律放 `HumanFinalReview.md`；`/ocap-review` **不得改寫 HumanReview.md**。

人類文件用詞以白話為優先；可以保留必要技術名詞（Project、Function、E2E、API），但標題與說明避免「決策摘要、影響面矩陣、驗收閘門」這類不必要的抽象詞。

### 1. 這次要做什麼
最多 4–5 點：
- `需求`：這次新增/修改什麼。
- `不變`：哪些原功能、API、資料、狀態一定要繼續支援。
- `範圍`：哪些 Project 會改 production；哪些只測試、只讀或刻意不動。
- `主要風險`：只列真的可能讓需求失敗或改 A 壞 B 的 1–3 點。
- `目前狀態`：規劃中 / Spec Review PASS / FAIL / BLOCKED；**不在這裡放 Final Review 狀態**。

### 2. 會改哪些地方（依 Project 分 Section）
先用一行列 `MODIFY / TEST_ONLY / READ_ONLY / 保護不動`，之後每個相關 Project 用獨立 Section，例如 `### Project: api — MODIFY`。

`MODIFY` Project 至少列：
`C/U/D | File::Class.method / Code Area | 預計 +/- LOC/Size | Before → After | 原功能 / caller 影響`

規則：
- **不放「實際 +/- LOC」欄位**；HumanReview 只寫 planning estimate。Actual 只在 HumanFinalReview。
- `Before → After` 用白話寫清楚哪個條件、資料、呼叫或錯誤處理會改。
- `原功能 / caller 影響` 只允許三種寫法：
  - `無影響`：原本功能/caller 仍支援，設計沒有拿掉或改變它的既有語意；相對應 regression 要列在第 4 區。
  - `有影響：<具體行為>`：真的改變舊語意、回傳、資料、狀態或 caller contract。
  - `待確認：<缺什麼證據>`：目前無法可靠判斷。
  不要在「無影響」時硬寫一大段相容性敘述。
- 一個 `MODIFY` Project **可以有多個「修改點」**；不要為了版面把整個 Project 強塞成一段 pseudocode。
  - 以不同責任或不同 `File::Class.method / SQL / Config Area` 為主要切分單位；每個重要修改點各自列 `檔案/方法、預計 LOC/Size、目的、原功能 / caller 影響`，再附 **3–8 行簡單 pseudocode / pseudo-diff**。
  - 同一 method 內幾個彼此相關的小條件仍算同一修改點，不要切成碎片。
  - 多個低風險、同目的、同資料流的機械式修改可以合併成一個修改點，列涉及檔案清單與一段共用 pseudocode；不可為了完整性逐檔複製相同內容。
  - Project Section 先列**預計總修改量**，各修改點再列自己的預計 LOC/Size；加總明顯對不起來時要說明共用/重疊或估算原因。
- `TEST_ONLY` Project 不製造 production CRUD，只寫：`為什麼相關 | 原功能 / caller 影響 | 預計測什麼`。若 production 不改且功能仍支援，影響直接寫 `無影響`。
- DB/schema/config/infra 沒有 meaningful LOC 時，用 `1 migration / 2 columns / 3 keys / N/A` 等 size。

### 3. 主要流程（怎麼呼叫）
- 從入口開始，畫一張精簡 Mermaid：`UI/API/Job/CLI → 主要 Function → 跨 Project 邊界 → DB/event/HTTP → 回傳/錯誤`。
- Project 名稱要與第 2 區對得上；箭頭要分清 direct call、HTTP/RPC、event/queue、DB read/write、integration-test data handoff。
- 只畫本次最重要的一條端到端路徑；一般 3–6 個參與者、5–9 個步驟。
- 這是 **Planned Flow**。Actual Flow 只放 `HumanFinalReview.md`。

### 4. 會測哪些情境
明確列出最高價值的 **E2E / Integration / Regression**，不要只寫「會補測試」。表格：
`Case | 類型 | 情境 / 主要 Flow | 預期 | 保護的原功能 | Project | Test File::Method`

規則：
- 小改 1–2、一般 2–5、高風險/跨系統 3–7 個重點 case。
- 至少包含主要 success flow、最高風險 negative/boundary、最可能「改 A 壞 B」的 regression；跨 Project 要有 producer→consumer；DB/migration 視需要列 rollout/recovery。
- 規劃階段只列**要測什麼**，不寫 PASS/FAIL。真正結果只放 HumanFinalReview。
- 完整 unit/branch/coverage matrix 留在 `TestPlan.md`。

### 5. 規劃檢查結果
只顯示 **Spec Review**：`Plan Revision | FULL/SCOPED | PASS/FAIL/BLOCKED/NOT_RUN | spec_review_00X.md`。
- Spec Review 回答「這個計畫可不可以照著做」，不是 implementation PASS。
- Final Review 不寫回 HumanReview。要看實作後結果，直接看 `HumanFinalReview.md`。

### 6. 你要怎麼看
最多 3 點：
1. **需求對不對？** 看第 1 區。
2. **預計怎麼改合理嗎？** 看每個 Project 的 LOC、Before→After、pseudocode、`無影響/有影響/待確認`，以及主要呼叫流程。
3. **測試計畫夠不夠？** 看第 4 區是否涵蓋主流程、舊功能回歸與跨 Project 邊界。

`HumanReview.md` 不記錄人工最終接受；實作完成後的人工接受/退回依 `HumanFinalReview.md` + Reviewed Snapshot。

## Global Rules
- user prompt 與後續明確決策是一級需求來源，不能只相信已生成文件。
- 需求沒要求就不改；保護既有 behavior / contract / persisted data / flow。
- 最小設計、先 reuse；禁止為未來可能需求過度設計。
- Repository 可驗證時不虛構 path/function/API/DB。
- 已完成 T#、SR# resolution、test evidence、review history、actual facts 不可靜默刪除或重編。
- 新決策推翻歷史時保留 traceability，必要時標 `SUPERSEDED`。
- 只規劃：不修改 production code、不跑正式測試、不 commit、不 push。

Block 規則與 Global Rules 衝突時，以 Global Rules 為準。

## Status
- `CONVERGED`：所有適用 blocks Complete、HumanReview 已含規劃改動清單與測試計畫、無 blocking SR#、無重大未決問題（`AUTO` 包含 AI 選擇有 evidence 且無 blocker）。
- `NEED_INPUT`：互動模式仍有重大問題要 Grill。
- `BLOCKED`：`AUTO` 無法安全自行決策；清楚留下阻擋事項/可選方案/影響，CLI 可以結束本次規劃，不等待輸入。
- `BLOCK_CONFIG_ERROR`：Core/registry/block contract 不合法。
