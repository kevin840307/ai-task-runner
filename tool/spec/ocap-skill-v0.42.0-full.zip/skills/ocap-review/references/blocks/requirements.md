---
block: requirements
role: check
priority: 100
always: true
---

# Requirements

## Match
所有 Review 都適用；Scoped Review 只檢查指定 scope 內 Requirement/Acceptance 及其必要依賴。

## Inspect
逐一對照 **user prompt/後續明確決策**、Requirements/Acceptance、actual diff、observable behavior、TODO/evidence；找漏做、半做、偷偷改語意、edge/error/recovery 未完成。

## Findings
未滿足主要 Requirement 通常 HIGH；局部 edge 依 impact MEDIUM/HIGH。只報可證明的缺口。

## Complete
所有 scope 內 user prompt intent 與 Requirement/Acceptance 均有 evidence 或已形成 finding。
