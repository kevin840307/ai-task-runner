---
block: regression
role: check
priority: 90
always: false
---

# Regression

## Match
Review scope 有 production behavior/code diff，或可能影響既有 caller/contract/state/runtime flow 時適用。

## Inspect
callers、public contract、persisted format、UI/worker/runtime flow、restart/resume、既有測試與相容性。把「原功能不受影響」當一級 Requirement。
- 多專案時先比對 Project Impact Matrix 與 actual diff：不該修改的 READ_ONLY/UNAFFECTED project 是否真的沒有 production diff；TEST_ONLY consumer 是否只補必要 regression。
- shared library/API/DTO/schema/public method 變更要逐主要 consumer 檢查舊 caller/舊 payload/舊 invocation；新 producer 測試通過不能證明 consumer 相容。
- actual 新增 Project/Service/Dependency 必須有 Requirement/Architecture 理由，否則報 scope expansion/overdesign。
- 做 **A→B Regression Sweep**：對每個 changed file/function 列出主要 caller、相鄰 feature、shared state/contract、background job/UI/CLI/API consumer；每個可能被連帶破壞的高價值 B 都要有 regression evidence、finding 或列入 `Human Final Review Focus`，不能只證明 A 的新需求本身。

## Findings
明確破壞既有主要功能通常 HIGH；次要真實 regression MEDIUM。

## Complete
受影響既有行為都有 regression evidence 或 finding。
