---
block: docs
role: check
priority: 40
always: false
---

# Docs / Traceability

## Match
存在 `ocapspec/` 或 Review scope 明確包含規格/規劃文件時適用。

## Inspect
檢查**所有受影響 generated md** 與 actual diff/evidence 是否一致，並特別確認：
- `Spec.md` 是否與 user prompt/後續決策一致，R#/Acceptance 無語意漂移，`Plan Revision` 與 `Requirement Sources` 是否能支持跨 Session 回溯。
- Spec Review 與 Final Review 必須分離：`HumanReview.md` 保持 planning/Spec Review 文件，**Final Review 不修改它**；最新 `review_00X.md` 與 `HumanFinalReview.md` 才承載 actual Final 結果。
- 任何 Skill 發現 stale generated md 都應 reconciliation；Review 檢查 `Spec/Architecture/TestPlan/TODO/HumanReview/spec_review_*/review_*` 的 Current Validity 是否一致。歷史 verdict/evidence 只能追加 STALE/SUPERSEDED 註記，不得被覆寫。
- `Architecture.md > Function Call & Data Flow` 是否基於真實 source/diff：入口→主要 function→跨專案同步呼叫或 event/HTTP/DB 資料交接→回傳/錯誤；不應把測試中的資料傳遞畫成真實 runtime call。
- `Architecture.md` 是否為人可讀的真實 change map；Implement 後是否保留 Planned/Est. 並補 Actual/Actual LOC/Drift，而不是覆寫規劃歷史。
- `TestPlan.md` 的 `[MUST-REVIEW]` scenarios 是否真的是最高價值代表案例；可依 change surface 是 E2E/Integration/API/CLI/migration/config/recovery/docs validation，不能因此漏掉完整 changed/new behavior/evidence。
- Implement 是否持續做 Doc Sync：actual diff/behavior 已改變時，`Spec.md / Architecture.md / TestPlan.md / TODO.md` 不得仍停在舊規劃；Architecture 應保留 Planned 並補最新 Actual/Drift/affected existing functionality。
- 不要求 HumanReview 反映 actual flow；Final Review 應檢查 `HumanFinalReview.md` 的 Actual Flow 是否與 canonical Architecture / source / diff 一致。
- `HumanFinalReview.md` 是否由**本次最新 Final Review**重建，Verdict/Scope/Plan Revision/Reviewed Snapshot 與 `review_00X.md` 完全一致；Requirement 完成度、**依 Project 的實際 File::Method + Actual LOC/Size + Before→After + 簡短 Actual pseudocode + 原功能影響**、Actual Function/Data Flow、A→B Regression、**明列的 E2E/Integration/Regression 驗收 cases**、Unverified 與人工驗收項目都有 evidence。若 snapshot 已變更而仍顯示 VALID/PASS，至少 MEDIUM/HIGH finding。
- Final Review 不重建或補 actual 到 `HumanReview.md`。若需要回看原規劃，只驗證它仍對應當前 Plan Revision/Spec Review；actual Project/LOC/tests 以 `HumanFinalReview.md` 為準。
- stable IDs/mapping、checkbox/PASS 是否真實。
- 新 `review_00X.md` 的 actionable findings 是否全部位於 `## Review TODO`；舊 `## TODO` 只作 backward compatibility。
- `## Observations` 是否和 blocking actionable SR/RV checkbox 明確分離；不能讓 PASS 被未完成低嚴重度建議誤阻擋。
- `HumanFinalReview.md` 的實際結果必須有真正 test/diff/snapshot evidence；不得因 HumanReview 的 planning 描述推論 PASS。
- review history 是否被破壞。

- HumanReview 在規劃階段呈現預估 LOC、pseudocode、原功能影響與預計 E2E/Integration/Regression；Final actual 不回填。HumanFinalReview 才呈現實際 LOC、真正測試證據、snapshot/verdict 與人工驗收。
- `HumanReview.md` 人工接受狀態不得由 AI 自行勾選；只有真實使用者回覆與對應 snapshot 才算核准。

## Findings
假完成、假 PASS、重大 docs/architecture drift 依 impact MEDIUM/HIGH；純文字美觀或格式偏好不列。

## Complete
人類 Review 層與 AI traceability 層都和實際 requirement/code/tests 一致。
