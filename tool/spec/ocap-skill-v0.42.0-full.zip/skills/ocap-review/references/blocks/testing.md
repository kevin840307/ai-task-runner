---
block: testing
role: check
priority: 85
always: false
---

# Tests / Coverage

## Match
Review scope 有 changed/new production behavior 或 production code diff 時適用。

## Inspect
不要只看 ``[MUST-REVIEW]` scenarios`。實際檢查：
- 每個 changed/new production behavior 是否有 meaningful test；驗收中的**排除條件與原本必須不變的行為**是否有負面/回歸斷言，而非只有正向 contains/assert。
- 既有測試是否先建立 baseline，新增測試是否直接檢查新/舊參數組合、順序、錯誤與邊界（適用時）。
- success/branch/error/boundary/state transitions 是否覆蓋；對**每個實際 changed function/method**，從 source/diff 反查既有 exception、early-return、條件 branch，確認沒有因新功能只測主線而漏掉舊錯誤行為；若使用 optional payload/DTO/contract，檢查 absent vs present-null vs falsy/invalid 的重要區別是否有對應 assertion（只測適用語意）。
- 對可量測 changed code，line + branch coverage 是否盡量接近 100%；**changed function 的 branch/exception gap 要逐項點名**，不能用整體 statement coverage 100% 掩蓋；任何 gap 都必須逐項有 justified exception + alternate evidence。
- 對 migration/config/infra/docs 等非 code change，是否有符合真實風險的 validation evidence，而不是硬套 coverage。
- Unit + 適當 Integration/E2E 是否符合真實邊界，不接受只靠 mock。
- 多專案是否有：每個 MODIFY project 的 local tests、TEST_ONLY consumer regression、至少一條真正跨 producer→consumer boundary 的 contract/integration evidence（適用時）。
- public method/function signature/API/DTO/schema 改變時，舊 caller/舊 payload/舊 invocation 是否仍被測；若預期 breaking，是否有明確核准與 migration/rollout test。
- `[MUST-REVIEW]` scenarios 是否涵蓋最重要 acceptance/regression/data-state risk，且保持精簡；Final Review 必須能把它們整理成 `Layer | Project/Boundary | 主要 Flow | Expected | Protected behavior | Test File::Method | Result`，讓 HumanFinalReview 明確回答實際跑了哪些 E2E/Integration/Regression；不限定一定是 E2E，也不可把 integration 假稱 E2E。
- 主動做 **A→B Regression Sweep**：從每個 changed file/function 的 callers、shared contract、persisted state、相鄰 feature、background job/UI/CLI/API consumer 反查「改 A 可能壞哪些 B」，每個高風險 B 要有既有測試 evidence、補 regression test 或列入 Unverified/Final Review Focus；不能只測新需求本身。
- baseline + targeted + affected regression + full applicable suite + build/lint/typecheck 是否真的執行；有 migration/rollout 時，pre-migration baseline、migration validation、post-migration runtime regression 是否在正確的 schema/runtime 階段執行。

- 每個新增/修改 test 方法是否有**易懂的語意名稱 + 相鄰簡短註解/docstring**，說明測什麼、期待什麼、保護什麼；文字內容必須與實際 fixture/assertion 一致，不能只有 TestPlan 寫了說明。
- `TestPlan.md` 的 Test File C/U/D/Method 清單是否與實際 diff 相符；重要 negative/regression case 是否有反例，不接受只看 coverage 就宣稱測試完善。

## Findings
關鍵 behavior 未測、changed code 大量漏測、只靠 mock、或未跑必要 full regression 通常 HIGH；局部真實缺口 MEDIUM。拒絕 meaningless assertion、coverage exclude、skip failure 或只測 implementation detail。

## Complete
changed/new behavior 與 regression/full-suite evidence 足以證明修改，而不是只有少量 E2E 看起來通過。
