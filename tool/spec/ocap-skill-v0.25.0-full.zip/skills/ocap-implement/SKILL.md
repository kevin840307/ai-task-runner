---
name: ocap-implement
description: Workflow engine for extensible implementation. Treat the user prompt as first-class runtime context, discover executable blocks, select one block per cycle with true fallback semantics, reroute after state changes, and never declare completion while canonical actionable OCAP work remains.
---

# ocap-implement

直接輸入 `/ocap-implement` 即可。`SKILL.md` 只負責 Workflow + Global Rules；work discovery、詳細做法、writeback、完成條件由 `references/blocks/*.md` 決定。

## Runtime Context
所有積木共用：
- 本次 user prompt：指定 work、scope、限制、優先順序、驗證要求、禁止事項。
- Repo/workspace/branch/worktree/git status & diff/instructions。
- `ocapspec/` 與 review history。
- test/build/lint/typecheck/coverage 能力。
- 前一積木產生的 evidence/state。

User prompt 是一級輸入，不可只照預設 queue：
- 明確指定 work/scope → **Scoped Invocation**。
- 無指定 work/scope → **Full Invocation**。
- prompt 中的限制/禁止事項要傳給 block。
- prompt 提到 block 名稱只算 hint。
- 若 prompt 要改 confirmed Requirement/Acceptance/重大 Architecture/Public Contract/DB 語意 → `NEED_REPLAN`。

## Invocation Scope
### Full
自動處理所有可執行 work，直到 Global Completion Gate 成立。

### Scoped
只允許處理 user 指定 work 與其**必要依賴**：
- 每次 candidate selection 都必須先過 scope filter。
- `SCOPE_COMPLETE` 是可信任的綠燈：指定 scope 的 Requirement/Acceptance、必要 tests/coverage/regression、docs/evidence 都必須完成。
- 只要必要驗證/evidence 被禁止、不可取得或未執行，就回 `BLOCKED`；可說明 code 已完成，但**不得**回 `SCOPE_COMPLETE`。
- `SCOPE_COMPLETE` 後立即停止，不得繼續 unrelated work。

User prompt 本身可成為 **Transient Work Item**。若它要求 production 變更但沒有既有 T#/RV#/其他 source：
- block 可直接處理明確的小修；若應納入既有 Spec traceability，先由適用 block寫回對應 work source。
- 若其實是新 Requirement 或重大 scope change → `NEED_REPLAN`。

## Workflow
1. Discover：掃 `references/blocks/*.md`。
2. Validate：每個 block 必須有唯一 `block`、整數 `priority`、boolean `fallback`，以及 `Match / Work Discovery / Execute / Writeback / Complete`；最多一個 fallback。
3. Candidate：所有符合 Match 的 block 各找一個 candidate。
4. Scope Filter：Scoped Invocation 只保留 scope/必要依賴 candidate。
5. Fallback Filter：
   - 只要存在任何 `fallback: false` candidate，**完全排除 fallback candidates**。
   - 只有沒有 non-fallback candidate 時，才允許唯一 `fallback: true` candidate 參選。
6. Select：在剩餘 candidates 中，user 指定 work 優先；再依 priority；同分用更具體 Match，再以 filename 排序。
7. Execute：一次只執行一個 block。
8. Block 完成或 state 改變後 `REROUTE`，重新 Discover/Select；不得硬跳特定 sibling block。
9. Scoped Invocation 只有 Scoped Completion Gate 全部通過才 → `SCOPE_COMPLETE`；否則依原因 `BLOCKED/NEED_REPLAN/NEED_SPEC`。
10. Full 無 candidate → Global Completion Gate。

新增能力只加一個 block md；移除只刪該 md。主 Workflow 不寫死 queue、source、writeback 或 block transition。

## Global Rules
- 只改 Requirement/work item 需要的行為；保護既有功能。
- 最小可維護 diff、先 reuse；不順手重構/換框架/升無關依賴。
- 沒必要不新增 service/abstraction/dependency/schema/API/config。
- 所有 changed/new production behavior 都要測。
- changed/new line + branch coverage 越接近 100% 越好；未覆蓋 changed line/branch 必須逐項有 justified exception + alternate evidence。
- targeted → regression → 適用 Integration/E2E → full applicable suite + build/lint/typecheck。
- 禁止 meaningless assertion、coverage exclude、skip/吞錯等假 PASS。
- 不做 destructive git；除非 user 明確要求，不 commit/push/release。

## Canonical Persistent Work
任何 block/extension 若要建立 persistent work：
- Core implementation work 使用 `## TODO`。
- Review findings 使用 `## Review TODO`。
- 其他 extension-created work **必須**使用 `## Actionable Work`。
- `## Work Items` 與舊 review `## TODO` 僅為 backward compatibility。
- stable ID 可擴充，例如 T#/RV#/M#/SEC#/PERF#，但必須唯一且可追蹤。

## Generic Actionable-Work Gate
只在 `ocapspec/**/*.md` 的下列 section（含子 section）掃 unchecked stable-id checkbox：
- `## TODO`
- `## Review TODO`
- `## Actionable Work`
- `## Work Items`（legacy compatibility）

規則：
- `- [ ] <stable-id> ...` 視為 actionable，除非明確標示 `BLOCKED`、`SUPERSEDED` 或 `NON_ACTIONABLE`。
- 其他 section（例如 Human Review / Acceptance checklist）不是 work queue。
- Full Invocation 宣告完成前必須掃上述 actionable sections。
- 若仍有 actionable work，但現有 blocks 都找不到 candidate → `BLOCK_NOT_FOUND`，列出 orphan work；不得 `READY_FOR_REVIEW`。

## Global Completion Gate
Full Invocation 只有在「無 block candidate + Generic Actionable-Work Gate 為空」時檢查：
- Requirements/Acceptance 有 evidence。
- changed/new behavior 全測；changed line/branch coverage 越接近 100% 越好，任何 gap 都有 justified exception + alternate evidence。
- regression/full suite/build/lint/typecheck 通過；必要 evidence 未執行不得當 PASS。
- 無已知原功能 regression、無關重構、額外架構、debug artifact。
- 各 work source 已依 block Writeback/Complete 收斂。
- 同步 `Architecture.md` 時保留 Planned/Est. 歷史；只補 Actual/Actual LOC/Drift，不覆寫原規劃。
- 無 blocker /重大 drift。

符合 → `READY_FOR_REVIEW`；未完成 work 無 block → `BLOCK_NOT_FOUND`；registry 錯誤 → `BLOCK_CONFIG_ERROR`。

## 輸出
保持短，讓人直接 Review 實作結果：
```text
Status: READY_FOR_REVIEW | SCOPE_COMPLETE | BLOCKED | NEED_REPLAN | NEED_SPEC | BLOCK_NOT_FOUND | BLOCK_CONFIG_ERROR
Work: <source / scope>
Changed: <主要 production behavior/files>
Preserved: <重要既有 behavior/contracts>
Tests: <targeted/regression/E2E/full suite 摘要>
Coverage: <changed line/branch；有數據才列>
Diff: <production files / test files / +/- LOC；可取得才列>
Remaining/Blocker: <有才列>
```
不要輸出冗長 command log；詳細 evidence 寫回原 work source/TestPlan。
