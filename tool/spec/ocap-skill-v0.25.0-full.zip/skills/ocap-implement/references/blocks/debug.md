---
block: debug
priority: 80
fallback: false
---

# DEBUG

## Match
問題已確認，但 root cause 未知、偶發、無法穩定重現，或尚不能判定 code/test/environment/spec。

## Work Discovery
找 user 指定 investigation、unchecked review finding 或 failing/runtime symptom 中 root cause 不足者。Review 依 severity 優先。

## Execute
建立最小 reproduction/failure signature → 收集 evidence → 縮小 root cause。未確認 root cause 前不亂改 production code；確認後只更新 state/evidence 並 `REROUTE`。

## Writeback
Review source 回原 RV# 寫 `Diagnosis/Evidence/Blocker`；其他 source 回原 source或真正受影響的 TestPlan/Architecture。不要指定下一個 block。

## Complete
診斷完成不等於 defect 修好。root cause 明確後 `REROUTE`；同一 failure 3 次無實質進展 → `BLOCKED` 並記已嘗試內容/解除條件。
