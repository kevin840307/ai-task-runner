---
name: ocap-spec-grill
description: Workflow engine for concise OCAP planning. Build context from the user prompt, repository and existing ocapspec, run four required planning core blocks plus applicable extensions, Grill only unresolved high-impact decisions, and preserve a human-readable planning surface.
---

# ocap-spec-grill

直接輸入 `/ocap-spec-grill` 即可。`SKILL.md` 只負責 Workflow + Global Rules；規劃細節與寫回檔案由 `references/blocks/*.md` 決定。

## Runtime Context
建立所有積木共用 context：
- 本次 user prompt：需求、補充、限制、偏好、指定 scope。
- Repository / workspace / instructions / relevant code/tests/contracts/storage。
- 現有 `ocapspec/`、已確認決策、完成歷史、review history。
- 本輪新 evidence / 使用者回答。

有 prompt 必須納入所有積木；已有 `ocapspec/` 且無新 prompt 時，直接繼續完善，不要求重述需求。

## Workflow
1. Discover：掃 `references/blocks/*.md`。
2. Validate：
   - Required Core Blocks 必須存在：`requirements`、`architecture`、`testing`、`todo`。
   - 缺少任一 Core Block、重複 block 名稱、frontmatter/type 不合法或缺必要 Section → `BLOCK_CONFIG_ERROR`。
   - 每個 block 必須有唯一 `block`、整數 `priority`、boolean `always`，以及 `Match / Analyze / Grill / Writeback / Complete`。
3. Select：Core Blocks 永遠參與；Extension Blocks 依 `always/Match` 判斷。依 priority 高到低分析。
4. Analyze：所有適用 block 讀同一 Runtime Context。
5. Grill：彙整、去重高影響未決問題；每輪最多 3 題，只問會改變需求、架構、相容性、資料、錯誤恢復或驗收的問題。
6. 使用者回答後更新 Runtime Context，重新跑適用 blocks。
7. 沒有重大未決問題時，各 block 依自己的 `Writeback` 更新文件。
8. 重新跑 blocks 做一致性檢查；全部 Complete 才 `CONVERGED`。

## Core vs Extension
- `requirements / architecture / testing / todo` 是 OCAP Planning 的 **Core Blocks**，屬於 Workflow baseline，不是可任意拔除的 extension。
- 未來新增能力（例如 migration/security/performance planning）使用新的 md 作為 **Extension Block**。
- 新增 Extension = 加一份 md；移除 Extension = 刪該 md；主 Workflow 不需要因 extension 增刪而改。
- Extension 不得要求另一個特定 Extension 一定存在；可依 Core 產物工作。

### Persistent Work Contract
Extension 若需要留下可被 Implement 消化的 persistent work：
- **必須**寫在 `## Actionable Work`（含其子 section）下。
- 每個 item 使用 stable ID，例如 `M1`、`SEC2`、`PERF3`：`- [ ] M1 ...`。
- 不得自己創造 `## Migration Tasks`、`## Security Queue` 等新的 actionable section 名稱，否則 Generic Actionable-Work Gate 無法保證 orphan detection。
- Core `TODO.md` 繼續使用 `## TODO`；Review 使用 `## Review TODO`。
- 舊文件的 `## Work Items` / review `## TODO` 只作 backward compatibility，不作新格式推薦。

## Human Review Contract
文件同時給 AI 與人使用，但人的主要 Review 入口固定：
- `Spec.md`：人主要看第一個 `## Summary`；Summary 必須約一個畫面內看懂需求。
- `Architecture.md`：**整份都是 Human Technical Review 文件**，必須由上到下可讀懂架構、flow、改動位置、原因、影響與 code sketch。
- `TestPlan.md`：人主要看第一個 `## Must-Review E2E`；只放最重要的代表案例。
- `TODO.md`：主要給 Implement/AI 執行與追蹤，保持小而可執行，不重複其他文件。

不得另外建立 HumanReview.md 複製相同資訊，避免雙重 source of truth。

## Global Rules
- 需求沒要求就不改；明確保護既有 behavior / contract / persisted data / flow。
- 最小設計、先 reuse；禁止為「未來可能用」過度設計。
- 文件簡潔有力：只留會影響 Review、實作、測試、驗收的內容。
- Repository 可驗證時不虛構 path/function/API/DB。
- 已完成 T#、test evidence、review history、actual facts 不可被靜默刪除或重編。
- 新決策推翻歷史時保留 traceability，必要時標 `SUPERSEDED`。
- 只規劃：不修改 production code、不跑正式測試、不 commit、不 push。

Block 規則與 Global Rules 衝突時，以 Global Rules 為準。

## Status
- `CONVERGED`：所有適用 blocks Complete 且無重大未決問題。
- `NEED_INPUT`：仍有重大問題要 Grill。
- `BLOCK_CONFIG_ERROR`：Core/registry/block contract 不合法。
