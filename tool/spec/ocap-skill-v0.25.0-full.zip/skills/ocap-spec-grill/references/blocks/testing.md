---
block: testing
priority: 80
always: true
---

# Testing

## Match
所有會修改或新增 production behavior 的規劃都適用。

## Analyze
列出所有 changed/new behavior、success/branches/error/boundary/state transitions、受影響既有功能與可用 test/build/lint/typecheck/coverage 能力。

## Grill
只有測試環境、live/mock 邊界、不可測條件會實質影響驗收時才提問。

## Writeback
更新 `ocapspec/TestPlan.md`。

第一個 Section 固定是 `## Must-Review E2E`，只放**人最值得看的代表案例**：
- 簡單需求約 2–4 個。
- 一般需求約 3–5 個。
- 複雜需求通常 4–6 個。
- 每個 case 用短格式：Scenario / Steps / Expected / Protected behavior。
- 優先選能直接驗收需求、跨邊界、最容易回歸或最重要既有功能的案例。
- 不要把所有 unit/branch cases 搬到這裡。

Must-Review E2E 之後才寫 AI/驗證細節：

### Coverage / Behavior Matrix
- **所有 changed/new production behavior 都必須有測試，不只是 Must-Review E2E。**
- changed/new success path、branch、error path、boundary、state transition 原則上全部覆蓋。
- changed/new code 的 line + branch coverage **越接近 100% 越好**；有 diff coverage 工具時優先看 diff coverage。
- 未覆蓋的 changed line/branch 必須逐項有 **justified exception + alternate evidence**；不能只寫「難測」。
- 不得用 meaningless assertion、implementation-detail-only test、coverage exclude、skip failure 等方式灌 coverage。

### Test Layers
依實際專案規劃：
- Unit：邏輯與 branches。
- Integration：component/API/DB/worker 等真實邊界。
- E2E：主要 observable workflow / regression。
- 高風險 concurrency/recovery/security/migration 額外 fault/boundary probes。

### Execution Gate
規劃實際執行順序：
`targeted → affected regression → Integration/E2E → full applicable suite → build/lint/typecheck`

未實際執行不得在 Implement/Review 階段標 PASS。

## Complete
人只看 Must-Review E2E 就能判斷「最重要驗收怎麼測」；AI 同時擁有完整 changed/new behavior coverage、regression 與 full-suite 計畫。
