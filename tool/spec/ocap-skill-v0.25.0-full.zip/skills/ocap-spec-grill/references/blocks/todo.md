---
block: todo
priority: 10
always: true
---

# TODO

## Match
規劃需要交給 implement 執行時適用。

## Analyze
依 Requirements、Architecture、TestPlan 建立最小可執行工作；不把每個 coding 微步驟都拆成 TODO。

## Grill
只有任務依賴或 ownership 無法從 Repo/其他 blocks 推導時才提問。

## Writeback
更新 `ocapspec/TODO.md`。TODO 主要給 AI/Implement 執行：

- stable `T#` checkbox。
- owning project / dependency。
- 對應必要 R#/F#/C#/DB#/E#/I#/U#。
- 完成 evidence。
- 保留既有 completed/blocked/superseded 狀態，不因重新 Grill 重編。
- 最後包含 regression / full validation / independent review gate。

不要在 TODO 複製 Architecture 的 file/code sketch 或 TestPlan 的 testcase；用 stable ID mapping 指回去即可。
不要把 import、單一 assertion、改一行 CSS 等 coding 微步驟各拆一個 T#。

## Complete
所有規劃內容可由 TODO 驅動完成，沒有 orphan Requirement/Architecture/Test obligation。
