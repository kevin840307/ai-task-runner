---
block: architecture
priority: 90
always: true
---

# Architecture

## Match
所有 implementation planning 都適用。

## Analyze
依 Repo reality 找最小修改位置、受影響 project/component/file/function/class/caller/contract/storage 與既有 flow。優先沿用現有 pattern。

**先讀真實程式碼再寫 Architecture。**
已存在的 file/function/class 要用實際名稱；尚未存在的名稱才標 `PROPOSED`，不要把猜測寫成事實。

## Grill
只有新增 service/framework/dependency/schema/public contract、重大 state/recovery/data design，或存在兩種明顯不同架構取捨時才提問。

## Writeback
更新 `ocapspec/Architecture.md`。這份文件**整份都要讓人看得懂**，建議依下列順序；不適用 Section 直接省略：

### 1. Overview
用短文說明：
- 現在架構/流程怎麼工作。
- 這次打算怎麼改。
- 哪些 project/component 明確不改。
- 為什麼這是最小合理方案。

### 2. Current → Proposed
用簡單文字 flow 或必要時 Mermaid 表示 before/after。

Mermaid 只在跨多 component、state 或資料流時使用；簡單流程用文字箭頭即可。

### 3. Projects / Components
每個受影響 project/component 說明：
- 負責什麼。
- 為什麼需要改。
- 會影響目前哪些功能/呼叫者。
- 哪些相鄰 component 不需要改。

### 4. Change Map
每個**規劃會改的 production file** 至少列：

`F# | Project | File | Function/Class/Area | Action | Planned change | Why | Est. LOC (+/- range) | Existing behavior affected | R#`

規劃階段只填 Planned / Est.；實作後由 Implement **保留 Planned，不覆寫歷史**，再補：
- `Actual change`
- `Actual LOC`
- `Drift`：`NONE` 或簡述為何和規劃不同

規則：
- `Action`：Modify / Add / Delete。
- LOC 用合理範圍，例如 `+20~35 / -5~10`，不要假精確。
- Test files 可另表或簡列，不要混淆 production LOC。
- `Existing behavior affected` 必須寫目前哪個功能可能受影響，不只寫新功能名稱。
- 如完全不影響既有 behavior，也明確寫 `None beyond <new behavior>`。

### 5. Code Change Sketch
對主要 production change 顯示「code 大概會怎麼改」，方便人直接 Review 實作方向。

規劃內容標示為 `Planned`。Implement 完成後若實際做法不同：
- 保留原 `Planned`。
- 補最小 `Actual` sketch 或文字。
- 補 `Drift` 原因。
- 若沒有實質 drift，可只標 `Actual: matches planned`，不要重複整段。

每個重要 F# 優先包含：
- verified 現有 function/class signature 或 code area。
- `Before`：只摘出與決策相關的最小邏輯/pseudocode。
- `After / Planned`：小型 pseudo-diff、pseudocode 或 proposed signature。
- 若新增 function/class：標示 `ADD (PROPOSED)`，說明 input/output、責任與 caller。
- 若刪除：說明由什麼既有路徑取代。

例如：

```text
F2 taskFilter.ts :: filterTasks(tasks, status)

Before:
  if runningOnly:
      return tasks.filter(isRunning)
  return tasks

Planned:
  switch status:
    ALL       -> tasks
    RUNNING   -> filter(isRunning)
    COMPLETED -> filter(isCompleted)
    FAILED    -> filter(hasFailureEvidence && isStopped)
```

Code Sketch 是**設計草圖，不是預先寫完整實作**：
- 不貼整份檔案。
- 不為了看起來完整而發明不存在的 API。
- 簡單改動可用 3~15 行 pseudocode；複雜邏輯才展開。
- 必須能讓人判斷「這個實作方向有沒有做太多/改錯地方」。

### 6. Behavior Impact
清楚分：
- `Will Change`
- `Must Stay Unchanged`
- 主要 regression/compatibility surface

### 7. Optional Technical Sections
真的適用才寫：
- Contract / API
- State / Data / DB
- Migration / Rollback
- Error / Recovery
- Concurrency
- Observability
- Security boundary

### 8. Risks / Compatibility
只列會影響實作或 Review 的真實風險與 mitigation。

### 9. Implementation Drift
**只有實作後有實質差異才出現。**
摘要列出：
- 新增/刪除的 production file
- Est. vs Actual LOC 明顯差異
- flow/contract/state/code sketch 差異
- 差異原因與是否需要 Replan

無 drift 時省略或只寫 `None`，不要製造噪音。

## Complete
人從頭讀完整份 Architecture 能回答：
1. 系統現在與修改後怎麼跑？
2. 會改哪些 project/file/function/class？
3. 為什麼改這裡？
4. code 大概怎麼改/新增？
5. production diff 大概多大？
6. 會影響哪些既有功能？
7. 有沒有過度設計或不必要 scope？

同時每個 Requirement 有合理實作落點，無不必要新架構，重大相容性/資料風險已處理。
