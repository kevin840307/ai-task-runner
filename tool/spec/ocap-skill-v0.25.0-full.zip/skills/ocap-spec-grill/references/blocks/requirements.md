---
block: requirements
priority: 100
always: true
---

# Requirements

## Match
所有規劃都適用。

## Analyze
釐清問題、目前/預期行為、Scope/Non-goals、protected behavior、R#/Acceptance、已確認決策與必要假設。避免把實作細節當需求。

## Grill
只針對會改變產品行為、Acceptance、scope 或相容性的缺口提問。

## Writeback
更新 `ocapspec/Spec.md`。

第一個 Section 固定是 `## Summary`，而且必須能**單獨給人 Review**，約一個畫面內回答：

- `Goal`：要解決什麼。
- `Change`：這次會改什麼。
- `Unchanged`：哪些既有行為/Contract 明確不改。
- `Key Decisions`：只列真正影響行為/驗收的決策。
- `Acceptance`：人能直接判斷做完沒有的主要驗收。
- `Risks/Constraints`：只有重要的才列。

Summary 不塞 file/function/T#/mapping 等 implementation detail。

Summary 後才保留 AI/traceability 需要的：
- stable R#
- 詳細 Acceptance
- Scope / Non-goals
- 已確認決策 / assumption
- 必要 mapping

不要在 Spec 重複 Architecture/TestPlan/TODO 的內容。

## Complete
只看 Summary 就能確認「是不是我要的」；同時每個關鍵 R# 有可觀察 Acceptance，protected behavior 與 Non-goals 清楚。
