---
name: ocap-review
description: Independent review workflow engine. Treat the user prompt as review context, run applicable pluggable check blocks with explicit always/Match semantics, aggregate findings, perform a critical sweep, persist canonical Review TODO findings in the next review_00X.md, and determine the verdict.
---

# ocap-review

直接輸入 `/ocap-review` 即可。`SKILL.md` 負責 Workflow、Severity、Critical Sweep、review history 與 Verdict；領域檢查細節由 `references/blocks/*.md` 決定。

## Runtime Context
- user prompt：scope、focus、額外風險、指定 diff/range。
- Repo/workspace/instructions/git change set。
- `ocapspec/`、既有 review history。
- tests/build/lint/typecheck/coverage 與可重現 evidence。

User prompt 可縮小 Review scope或增加重點，但不能要求忽略已知嚴重 finding 或製造假 PASS。

## Workflow
1. Discover：掃 `references/blocks/*.md`。
2. Validate：每個 check block 必須有唯一 `block`、`role: check`、整數 priority、boolean always，以及 `Match / Inspect / Findings / Complete`。
3. Select Checks：
   - `always: true` = **任何 Review 都執行，Match 不作 gating**；Match 只可描述 scope/適用方式。
   - `always: false` = **只有 Match 成立才執行**。
4. Run：依 priority 高到低執行所有 selected checks。
5. Aggregate：以 root cause 合併重複 finding，保留最強 evidence/impact；不同 check 不重複報同一問題。
6. Normalize severity。
7. **Critical Sweep**：基於所有 evidence/change surface 做一次災難級後果檢查，確認沒有漏掉資料毀損、Auth bypass/RCE/重大 secret exposure、不可逆破壞、核心 state corruption、crash loop、重大重複副作用、嚴重 race/recovery failure、核心無人值守流程全面失效。這是 Workflow safety gate，不是額外 finding domain；若已由 check 發現，只升級/合併。
8. Determine Verdict。
9. Persist Review：建立下一個 `ocapspec/review_00X.md`。
10. 聊天只回短摘要。

新增 Review 能力只加一個 check block；移除只刪該 block。Critical/Verdict/Review persistence 是 Workflow invariant，不做成可刪 block。

## Review Persistence
每次 Review（Full 或 Scoped）都建立下一個：
- 掃既有 `review_*.md`，最大編號 + 1，固定 3 位數，永不覆蓋/重用。
- PASS 也建立 review 檔。
- 固定結構：
  - `Status: OPEN | DONE`
  - `Verdict: PASS | FAIL | BLOCKED`
  - `Scope Type: FULL | SCOPED`
  - `Scope: <range/work item>`
  - `## Summary`
  - `## Review TODO`
  - `## Unverified`（有才保留）
- **所有 actionable finding 必須寫在 `## Review TODO`**：
  `- [ ] RV# [SEVERITY][Domain]`
  並只寫必要 `Evidence / Impact / Expected / Handling hint / Tests / Mapping`。
- 沒有 finding 時 `## Review TODO` 可寫 `None`，不要創造假 checkbox。
- 有 actionable finding 或 BLOCKED → `Status: OPEN`；PASS 且無 finding → `DONE`。
- Finding 不綁定 implement block 名稱；Handling hint 只描述狀態。
- 舊 review 的 Verdict/history 不修改。
- 舊 review 若使用 `## TODO`，Implement 仍以 backward compatibility 消化；新 review 一律使用 `## Review TODO`。

## Global Rules
- Reviewer 獨立：不修 production code、不為了 PASS 弱化 finding。
- 主動找嚴重 bug，不只看 happy path。
- Severity：
  - `CRITICAL`：災難級資料/安全/核心可靠性破壞。
  - `HIGH`：主要 Requirement/contract/recovery 失效、重大 regression、實質安全漏洞、changed code 大量未測。
  - `MEDIUM`：真實 edge/coverage/reliability/maintainability 缺口。
  - `LOW`：有實際價值的小問題；純 style/偏好不列。
- CRITICAL/HIGH 一律阻擋 PASS；MEDIUM 依 impact；LOW 不單獨阻擋。
- Finding 必須有 Evidence + Impact + Expected，不得空泛 checklist。
- Review history 不覆蓋、不重編。

## Verdict
- `PASS`：scope 內 work queues 收斂、無阻擋 finding、Requirement/evidence 完整、所有 changed/new behavior 有 meaningful tests；changed line/branch coverage 越接近 100% 越好，任何 gap 都有 justified exception + alternate evidence；必要 regression/full applicable suite 有 evidence，且無重大 regression/overdesign/spec drift。
- `FAIL`：存在 CRITICAL/HIGH，或其他足以阻擋驗收的 finding / 未完成工作 / 關鍵驗證不足。
- `BLOCKED`：必要環境/資料不可取得，無法可靠判定。

Scoped Review 也必須寫入新的 `review_00X.md`，並標 `Scope Type: SCOPED`。Scoped PASS 只代表指定 scope，不可包裝成整體專案 PASS。

## 輸出
```text
Verdict: PASS | FAIL | BLOCKED
Review: ocapspec/review_00X.md
Critical: N | High: N | Medium: N | Low: N
Tests: <摘要>
```
