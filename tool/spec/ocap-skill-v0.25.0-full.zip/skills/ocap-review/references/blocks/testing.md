---
block: testing
role: check
priority: 85
always: false
---

# Tests / Coverage

## Match
Review scope 有 changed/new production behavior 或 production code diff 時適用。

## Inspect
不要只看 `Must-Review E2E`。實際檢查：
- 每個 changed/new production behavior 是否有 meaningful test。
- success/branch/error/boundary/state transitions 是否覆蓋。
- changed/new line + branch coverage 是否盡量接近 100%；任何 gap 都必須逐項有 justified exception + alternate evidence。
- Unit + 適當 Integration/E2E 是否符合真實邊界，不接受只靠 mock。
- Must-Review E2E 是否涵蓋最重要 acceptance/regression，且保持精簡。
- targeted + affected regression + full applicable suite + build/lint/typecheck 是否真的執行。

## Findings
關鍵 behavior 未測、changed code 大量漏測、只靠 mock、或未跑必要 full regression 通常 HIGH；局部真實缺口 MEDIUM。拒絕 meaningless assertion、coverage exclude、skip failure 或只測 implementation detail。

## Complete
changed/new behavior 與 regression/full-suite evidence 足以證明修改，而不是只有少量 E2E 看起來通過。
