---
block: docs
role: check
priority: 40
always: false
---

# Docs / Traceability

## Match
存在 `ocapspec/` 或 Review scope 明確包含規格/規劃文件時適用。

## Inspect
檢查 Spec/Architecture/TestPlan/TODO 與 actual diff/evidence 是否一致，並特別確認：
- `Spec.md` 的 Summary 是否能單獨正確代表需求，沒有和詳細 R#/Acceptance 矛盾。
- `Architecture.md` 是否為人可讀的真實 change map；Implement 後是否保留 Planned/Est. 並補 Actual/Actual LOC/Drift，而不是覆寫規劃歷史。
- `TestPlan.md` 的 Must-Review E2E 是否真的是最重要代表案例；不能因 E2E 清單短就漏掉 changed/new behavior 的完整測試。
- stable IDs/mapping、checkbox/PASS 是否真實。
- 新 `review_00X.md` 的 actionable findings 是否全部位於 `## Review TODO`；舊 `## TODO` 只作 backward compatibility。
- review history 是否被破壞。

## Findings
假完成、假 PASS、重大 docs/architecture drift 依 impact MEDIUM/HIGH；純文字美觀或格式偏好不列。

## Complete
人類 Review 層與 AI traceability 層都和實際 requirement/code/tests 一致。
