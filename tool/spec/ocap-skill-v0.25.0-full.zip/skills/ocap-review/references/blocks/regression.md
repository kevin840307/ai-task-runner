---
block: regression
role: check
priority: 90
always: false
---

# Regression

## Match
Review scope 有 production behavior/code diff，或可能影響既有 caller/contract/state/runtime flow 時適用。

## Inspect
callers、public contract、persisted format、UI/worker/runtime flow、restart/resume、既有測試與相容性。把「原功能不受影響」當一級 Requirement。

## Findings
明確破壞既有主要功能通常 HIGH；次要真實 regression MEDIUM。

## Complete
受影響既有行為都有 regression evidence 或 finding。
