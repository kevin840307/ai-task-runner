---
block: overdesign
role: check
priority: 70
always: false
---

# Overdesign / Scope

## Match
Review scope 有 implementation/architecture diff 時適用。

## Inspect
找不必要 service/abstraction/framework/dependency/schema/API/config、可 reuse 卻另造第二套、與 Acceptance 無關 refactor、修改檔案/LOC/複雜度明顯過大。

## Findings
若刪掉新增設計仍能完整滿足 Requirement 且更簡單相容，視為 overdesign；依風險 MEDIUM/HIGH。

## Complete
scope 與複雜度和 Requirement 相稱。
