---
block: security-reliability
role: check
priority: 75
always: false
---

# Security / Reliability

## Match
change surface 涉及 Auth/AuthZ、外部輸入、file/path/command/network、worker/background job、retry/recovery/concurrency、DB/migration 時適用。

## Inspect
依實際 surface 檢查 injection/XSS/SSRF/path traversal/secret、ownership/permission、race/idempotency/stale write/retry storm/timeout/cancel/restart/partial failure/migration safety。

## Findings
必須有可行 attack/failure path 或明確破壞假設，不做空泛警報。

## Complete
適用 security/reliability 邊界已被驗證或形成 finding。
