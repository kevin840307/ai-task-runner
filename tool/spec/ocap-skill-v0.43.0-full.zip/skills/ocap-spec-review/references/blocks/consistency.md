---
block: consistency
role: check
priority: 70
always: true
---

# Cross-document Consistency

## Match
所有 Spec Review 都適用。

## Inspect
做 cross-doc traceability / contradiction review：
- user prompt → R# → Architecture F#/change → T# → tests 是否閉環。
- 大型/多專案時 `Repository Discovery / Consumer Discovery Evidence → Project Impact Matrix → Change Map → TestPlan` 是否閉環；consumer 若出現在 discovery 卻沒有 mode/test/排除理由，視為 orphan impact。
- Requirement 是否沒有 implementation landing point。
- Architecture change 是否沒有 Requirement 理由。
- TODO 是否有不屬於任何 Requirement 的 scope creep。
- TestPlan 是否漏 Requirement/Architecture behavior。
- Spec 說「不改」但 Architecture/TODO 又規劃修改的矛盾。
- HumanReview 的核心資料流／Function Call Flow 是否從 `Architecture.md > Function Call & Data Flow` 衍生，函式名、資料/跨專案邊界、`PROPOSED/待查證` 與 Repo evidence 相符；沒有把 events 或 integration test handoff 畫成直接 runtime call。
- HumanReview 是否完整衍生且沒有獨有 decision/fact；一眼看懂的規模/風險、主要 change groups、原功能影響、LOC/Size 與 MUST-REVIEW scenarios 及預計變更的 Test files/methods 是否和 canonical docs 一致，且沒有漏掉真正高風險資訊。
- HumanReview 是否只呈現 planning + Spec Review；不得含 Final Review status、actual LOC、snapshot 或實際測試結果。Final actual 只屬於 HumanFinalReview。
- Generated-MD Reconciliation 後，所有受影響 `ocapspec/**/*.md` 是否為 current facts；舊 review 若過期應有 Current Validity `STALE/SUPERSEDED`，但原 Verdict/evidence 不得被改寫。
- 未完成 SR# 是否被錯誤忽略。
- `Plan Revision` 是否與已確認的 material planning changes 相符；HumanReview 的內容是否可從 canonical docs 追溯，而不是新增決策。
- `AUTO` 決策在 Spec/Architecture/TestPlan/TODO 與 HumanReview 是否一致；`AI_SELECTED` 是否有 evidence/影響/驗證；若 `BLOCKING_DECISION` 未解或被寫成可執行 TODO，應阻擋 PASS。

## Findings
跨文件矛盾導致可能做錯功能通常 HIGH；dangling mapping/derived-view drift 依 impact MEDIUM/HIGH。

## Complete
scope 內 prompt/R#/Architecture/TODO/tests/HumanReview 收斂一致，或每個缺口都有 finding。
