---
name: ocap-implement
description: Workflow engine for extensible implementation. Treat the user prompt as first-class runtime context, discover executable blocks, select one block per cycle with true fallback semantics, reroute after state changes, and never declare completion while canonical actionable OCAP work remains.
---

# ocap-implement

直接輸入 `/ocap-implement` 即可。`SKILL.md` 只負責 Workflow + Global Rules；work discovery、詳細做法、writeback、完成條件由 `references/blocks/*.md` 決定。

## Runtime Context
所有積木共用：
- 本次 user prompt：指定 work、scope、限制、優先順序、驗證要求、禁止事項。
- Repo/workspace/branch/worktree/git status & diff/instructions。
- `ocapspec/` 與 review history。
- test/build/lint/typecheck/coverage 能力。
- 前一積木產生的 evidence/state。

User prompt 是一級輸入，不可只照預設 queue：
- 明確指定 work/scope → **Scoped Invocation**。
- 無指定 work/scope → **Full Invocation**。
- prompt 中的限制/禁止事項要傳給 block。
- prompt 提到 block 名稱只算 hint。
- 若 prompt 要改 confirmed Requirement/Acceptance/重大 Architecture/Public Contract/DB 語意 → `NEED_REPLAN`。

## Global Generated-MD Reconciliation（所有 Skill 共用）
任何 OCAP Skill 執行時，只要取得的新 prompt、Repo、diff、test、coverage、review、runtime evidence 顯示**已產生的 Markdown 與現況不一致**，就必須在該次 invocation 內同步所有受影響的 generated md；不能因「這不是本 Skill 原本負責的文件」而留下 stale 狀態。

### 必須掃描的 generated md
至少包含存在的：
- `ocapspec/Spec.md`
- `ocapspec/Architecture.md`
- `ocapspec/TestPlan.md`
- `ocapspec/TODO.md`
- `ocapspec/HumanReview.md`
- `ocapspec/HumanFinalReview.md`（若已產生；僅 Final Review 建立，其他 Skill 只同步/標 STALE）
- `ocapspec/spec_review_*.md`
- `ocapspec/review_*.md`
- 其他由 OCAP block/extension 產生且與本次 evidence 有關的 `ocapspec/**/*.md`

### Reconcile 規則
1. **Current-state docs 直接同步現況**：檔案/Project/Function Call & Data Flow、Actual LOC、contract/data/state、test cases、coverage/evidence、TODO 狀態、風險、未驗證項等有新事實就更新。
2. **Requirement truth 不可被 implementation 倒推改寫**：若 actual code 與 user prompt/已確認 Requirement 不同，文件要同時保留「要求」與「Actual Drift」，標 `NEED_REPLAN/FAIL/BLOCKED`（依 Skill），不能把 Spec 改成配合錯誤實作來製造一致。
3. **Material planning change** 依 Planning Baseline 增加 `Plan Revision`；任何綁舊 Revision 的 Spec Review PASS 都標 `STALE/SUPERSEDED`，必須重新 Spec Review。
4. **Review history 保留原始證據**：`spec_review_00X.md` / `review_00X.md` 的原 Verdict、finding、snapshot、evidence 不覆寫、不刪除。後來 evidence 改變有效性時，可追加/更新 `## Current Validity / Reconciliation`，標 `VALID / STALE / SUPERSEDED`、原因與替代的最新 review。
5. **Implement 不把 actual 寫回 HumanReview**：HumanReview 是 planning/Spec Review 文件。Implement 更新 `Architecture/TestPlan/TODO/Spec` 的 actual facts；若 material drift 需要重規劃則回 `NEED_REPLAN`，由 Spec Grill 重建 HumanReview。
6. 同一 invocation 在輸出 PASS/READY/CONVERGED/SCOPE_COMPLETE 前，必須再次做 cross-doc consistency check；仍有已知 stale generated md 就不能宣告完成。若存在 `HumanFinalReview.md` 且本次 production/test/config/migration 變更超出其 Reviewed Snapshot，必須將它與對應 Final Review validity 標 `STALE`，不得讓人沿用舊驗收結論。
7. Auto-sync 只更新 Markdown/衍生狀態，不代表 Reviewer 可以修改 production/test code。只有 `/ocap-implement` 依 work item 修改交付內容；Spec/Final Review 仍保持 implementation independence。

## Invocation Scope
### Full
自動處理所有可執行 work，直到 Global Completion Gate 成立。

### Scoped
只允許處理 user 指定 work 與其**必要依賴**：
- 每次 candidate selection 都必須先過 scope filter。
- `SCOPE_COMPLETE` 是可信任的綠燈：指定 scope 的 Requirement/Acceptance、必要 tests/coverage/regression、docs/evidence 都必須完成。
- 只要必要驗證/evidence 被禁止、不可取得或未執行，就回 `BLOCKED`；可說明 code 已完成，但**不得**回 `SCOPE_COMPLETE`。
- `SCOPE_COMPLETE` 後立即停止，不得繼續 unrelated work。

User prompt 本身可成為 **Transient Work Item**。若它要求 production 變更但沒有既有 T#/RV#/其他 source：
- block 可直接處理明確的小修；若應納入既有 Spec traceability，先由適用 block寫回對應 work source。
- 若其實是新 Requirement 或重大 scope change → `NEED_REPLAN`。

## Optional Human Review Gate
- `HumanReview.md` 是**人看得懂的審查入口**，不是已核准證據。預設不強制人批准，避免讓無人值守 Auto CLI 無故卡住。
- 若 user/Repo policy 明確要求人核准規劃，`/ocap-implement` 必須在實作前檢查 `Spec.md` 已有**真實使用者明確** `USER_CONFIRMED` 核准，記錄 current `Plan Revision`、scope、來源；缺少則 `BLOCKED: HUMAN_APPROVAL_REQUIRED`。不可用 `AI_SELECTED` 或 AI 自行填字代替。
- 若 user/Repo policy 要求人驗收實作，最後接受狀態依 `TODO.md ## Human Acceptance` 內的**真實回覆與 reviewed code snapshot** 記錄；未核准不得宣稱人工驗收完成，但可如實回報 `READY_FOR_HUMAN_REVIEW`，不假稱 PASS。

## Spec Review Preflight
在進入第一次 production/delivery edit 之前，先核對 `Spec.md` 的 `Plan Revision` 與 `ocapspec/spec_review_*.md`：
- 若 `Grill Mode: AUTO` 且 `Spec.md` 尚有未解 `BLOCKING_DECISION` 或規劃狀態為 `BLOCKED` → `NEED_REPLAN`，不得自行填入假定決策後繼續；已妥善選擇且可驗證的 `AI_SELECTED` 本身不是阻擋項。
- 若相關 scope 仍有未完成**blocking SR#**（舊格式沒有標記的 unchecked SR# 仍視為 blocking，非 `SUPERSEDED/NON_ACTIONABLE`）→ `NEED_REPLAN`；`## Observations` 不是 implementation queue，不得誤阻擋。
- **若已有 Spec Review 歷史**：Full Invocation 必須有對應**目前 Plan Revision** 的最新有效 **Full PASS**；Scoped Invocation 可接受涵蓋該 scope/必要依賴且同 Revision 的 PASS。最新相應 Review 若為 FAIL/BLOCKED，或 PASS 版本過期/Scope 不涵蓋 → `BLOCKED`，明確列 `Rerun /ocap-spec-review`；不得沿用舊 PASS。
- **若完全沒有 Spec Review 歷史**：為相容既有流程，允許繼續，但輸出標 `Planning review: NOT_RUN`；不可假稱已通過 Spec Review。
- 舊版 review 若沒有可核對的 `Plan Revision`，不能視作目前版本的有效 PASS；可重新跑 Review 升級。不要自己補填已存在的 review 歷史。
- 只把 material planned change 視為 Revision 變更；Implement 按 `Implementation Drift & Doc Sync` 回填 Actual/Actual LOC/執行結果/TODO checkbox 時不增加 Plan Revision，也不會自動使原本 PASS 失效。
- `## Spec Review TODO` 是 planning queue，只由 `/ocap-spec-grill` 消化，Generic Actionable-Work Gate 不能接手。

## Workflow
1. Discover：掃 `references/blocks/*.md`。
2. Validate：每個 block 必須有唯一 `block`、整數 `priority`、boolean `fallback`，以及 `Match / Work Discovery / Execute / Writeback / Complete`；最多一個 fallback。
3. Scope Filter **先於 Work Discovery**：先限定本次可讀/可選的 work items 與其必要依賴，禁止其他 scope 把候選槽位佔掉。
4. Candidate：每個符合 Match 的 block 都在已限制的 work 集合中尋找最優先 candidate（不能先挑 scope 外的第一筆再丟棄）；Full 模式使用全部 work。
5. Fallback Filter：
   - 只要存在任何 `fallback: false` candidate，**完全排除 fallback candidates**。
   - 只有沒有 non-fallback candidate 時，才允許唯一 `fallback: true` candidate 參選。
6. Select：在剩餘 candidates 中，user 指定 work 優先；再依 priority；同分用更具體 Match，再以 filename 排序。
7. Execute：一次只執行一個 block。
8. Doc Sync：每次 production state/diff 或已確認 implementation fact 改變後，先執行 `Implementation Drift & Doc Sync` + `Global Generated-MD Reconciliation`；同步 canonical docs 與 Spec/Final Review validity，但**不把 actual diff/LOC/tests 寫回 HumanReview**。
9. Block 完成或 state 改變後 `REROUTE`，重新 Discover/Select；不得硬跳特定 sibling block。
   - **No-progress Guard**：同一 work item 若連續 3 輪沒有新的 evidence、diff、tests、診斷收斂或 work state 進展，停止重試並回 `BLOCKED`，記錄原因與解除條件；跨 DEV/FIX/DEBUG 也共享計數，不能靠 REROUTE 無限循環。
10. Scoped Invocation 只有 Scoped Completion Gate 全部通過才 → `SCOPE_COMPLETE`；否則依原因 `BLOCKED/NEED_REPLAN/NEED_SPEC`。
11. Full 無 candidate → Global Completion Gate。

新增能力只加一個 block md；移除只刪該 md。主 Workflow 不寫死 queue、source、writeback 或 block transition。

## Global Rules
- 只改 Requirement/work item 需要的行為；保護既有功能。
- change surface 不只 code：DB/migration、config、CI/CD、infra、scripts、public contract、docs-only 交付也適用。
- 只有可量測 code 才要求 changed line/branch coverage；其他 change surface 必須用最接近真實風險的 validation/evidence，不為了數字硬造 coverage。
- 最小可維護 diff、先 reuse；不順手重構/換框架/升無關依賴。
- 修改前對照 Architecture 的 change map 與現有測試；**多專案先讀 Project Impact Matrix，只有 MODIFY project 可以預期出現 production/delivery diff**。TEST_ONLY 只應出現測試/evidence；READ_ONLY/UNAFFECTED 不應有 production diff。修改後比對 `git diff`：額外 Project/File/依賴、呼叫行為變動都要有必要理由與回歸驗證。能用同樣正確、可讀的更小 diff，應收斂回較小方案；不可為了省行數寫不易維護的 code golf。
- 大型 repo 或 shared/public boundary 變更前，核對 Architecture 的 `Repository Discovery / Consumer Discovery Evidence`：critical consumer 若仍 `UNVERIFIED` 且可能影響 breaking contract/data/rollout，不能直接實作成「無影響」，應 `NEED_REPLAN/BLOCKED`。
- 實作中若 source/diff 新發現原規劃未列的 caller/consumer/project/area，立即更新 canonical evidence；若只是非語意 implementation drift 可同步，若改變 contract/scope/rollout/Requirement 則 `NEED_REPLAN`。
- 沒必要不新增 service/abstraction/dependency/schema/API/config。
- 所有 changed/new behavior 和可驗證的 delivery artifacts 都必須有相稱的驗證；每個新增/修改的 Test Case 都必須有具語意的函式/案例名稱與**貼近程式碼的簡短 comment/docstring** 說清楚測什麼、預期什麼、保護哪個原功能/回歸；不得只在 TestPlan 描述；沒有 runtime behavior 的變更仍要有 contract/config/schema/docs 等 appropriate evidence。
- 對**可量測的 changed code**，line + branch coverage 越接近 100% 越好；未覆蓋 changed line/branch 須逐項 justified exception + alternate evidence；不適用 code coverage 時寫 `N/A + validation evidence`。
- targeted → regression → 適用 Integration/E2E → full applicable suite + build/lint/typecheck。
- 禁止 meaningless assertion、coverage exclude、skip/吞錯等假 PASS。
- 不做 destructive git；除非 user 明確要求，不 commit/push/release。

## Implementation Drift & Doc Sync
實作是持續驗證規劃的過程。只要 actual code/diff/evidence 與 canonical planning docs 不一致，就要**當下同步**，不得明知文件過期還等到任務最後。

每次 state-changing implementation、root-cause fix、或新 evidence 讓 implementation facts 改變後：
1. Compare：比較 user prompt/confirmed decisions、`Spec.md / Architecture.md / TestPlan.md / TODO.md` 與 actual repo/diff。
2. Classify Drift：
   - **Project scope drift**：actual production diff 出現在原本 TEST_ONLY/READ_ONLY/UNAFFECTED project，或新增未規劃 Project。先判斷是否真正必要；不必要就撤回額外修改，必要且不改 confirmed semantics 則同步 Architecture/TestPlan/TODO 的 actual facts；若代表 contract/scope/Requirement material change → `NEED_REPLAN`，由 Spec Grill 更新 HumanReview。
   - **Implementation drift**：不改變已確認 Requirement/Acceptance/Public Contract/DB/state 語意，只是實際修改位置、方法、檔案、flow 細節、LOC、受影響既有功能、測試需求與原規劃不同。→ Implement 直接同步文件。
   - **Semantic drift**：需要改變已確認 Requirement/Acceptance、public contract、DB/schema、persisted-data semantics、重大 state/recovery semantics 或 user 已確認決策。→ 停止擴大 production 修改，記錄 evidence，回 `NEED_REPLAN`；不得自行改文件把 scope change 合理化。
3. Sync Canonical Docs（只改真正受影響的部分）：
   - `Architecture.md`：保留 Planned/Est.；補或更新 Actual、Actual LOC、Drift、實際 Projects/Change Map、`Function Call & Data Flow`（入口、主要 function calls、event/HTTP/DB 資料交接、失敗/回退）及**可能受影響的原有功能/流程**；若 Planned 與實際不同寫明原因，不得憑圖臆造呼叫。不要覆寫原規劃歷史。
   - `TestPlan.md`：同步實際新增/修改/刪除的 test file / method / case、用途說明、測試結果/證據；actual behavior/branch/error/boundary/state transition 或 integration surface 改變時立即同步 coverage matrix、test layers 與必要 `[MUST-REVIEW]` scenarios。
   - `TODO.md`：若實際 dependency、mapping、evidence 或 work decomposition 改變，立即更新；保留 stable T#，不要為了同步而重編已存在 ID。
   - `Spec.md`：只允許同步不改變已確認語意的 factual clarification/traceability；若會改需求語意，走 `NEED_REPLAN`。**不得變更已核准的 `Plan Revision` 來規避 Spec Review；需要 material replan 時由 Spec Grill 更新版本。**
4. Human docs：**不要把 implementation actual 回寫 `HumanReview.md`**。所有 Actual LOC、Actual Flow、實際測試/evidence 先同步到 canonical docs；若已有 `HumanFinalReview.md` 且 snapshot 因本次修改失效，只把 HumanFinalReview / review validity 標 `STALE`。需要改 planning semantics 時回 `NEED_REPLAN`，讓 Spec Grill 重建 HumanReview。
5. Re-check：同步後再確認 docs ↔ actual diff ↔ tests 一致，才可 Complete/REROUTE。

Doc Sync 不代表可以無限制改規格；它的目的，是讓文件永遠反映「已確認需求下的最新實作事實」。

## Canonical Persistent Work
任何 block/extension 若要建立 persistent work：
- Core implementation work 使用 `## TODO`。
- Review findings 使用 `## Review TODO`。
- 其他 extension-created work **必須**使用 `## Actionable Work`。
- `## Work Items` 與舊 review `## TODO` 僅為 backward compatibility。
- stable ID 可擴充，例如 T#/RV#/M#/SEC#/PERF#，但必須唯一且可追蹤。

## Generic Actionable-Work Gate
只在 `ocapspec/**/*.md` 的下列 section（含子 section）掃 unchecked stable-id checkbox：
- `## TODO`
- `## Review TODO`
- `## Actionable Work`
- `## Work Items`（legacy compatibility）
- **絕不**把 `## Observations` / `## Human Acceptance` 當 actionable queue；非阻擋建議需使用者明確轉成 TODO 才進入實作。

規則：
- `- [ ] <stable-id> ...` 視為 actionable，除非明確標示 `BLOCKED`、`SUPERSEDED` 或 `NON_ACTIONABLE`。
- 其他 section（例如 Human Review / Acceptance checklist / `## Spec Review TODO`）不是 implementation work queue。
- Full Invocation 宣告完成前必須掃上述 actionable sections。
- 若仍有 actionable work，但現有 blocks 都找不到 candidate → `BLOCK_NOT_FOUND`，列出 orphan work；不得 `READY_FOR_REVIEW`。

## Global Completion Gate
Full Invocation 只有在「無 block candidate + Generic Actionable-Work Gate 為空」時檢查：
- Requirements/Acceptance 有 evidence。
- changed/new behavior 與 non-code delivery artifacts 都有適用且可信的 validation evidence；有可量測 code 才要求 changed line/branch coverage 接近 100%，**每個 changed function 的既有 exception/early-return/branch gap 必須逐項說明**，gap 要有 justified exception + alternate evidence；不適用標 `N/A`。
- regression/full suite/build/lint/typecheck 通過；必要 evidence 未執行不得當 PASS。DB/migration/rollout 變更要確認 pre-migration baseline、migration validation、post-migration runtime regression 各自在正確階段完成，不能把 rollout setup 問題當成 code regression 或靠刪測試避開。多專案需確認每個 MODIFY project、本應 TEST_ONLY 的 consumer，以及跨專案 contract/integration evidence 都已完成。
- 無已知原功能 regression、無關重構、額外架構、debug artifact。
- shared/public boundary 的 confirmed consumers 都有對應 production adaptation、TEST_ONLY regression、READ_ONLY/UNAFFECTED evidence 或明確 UNVERIFIED；不可因 consumer 沒被最初列到就略過。
- 各 work source 已依 block Writeback/Complete 收斂；TestPlan 的每個 changed/new test case 可定位到真實測試檔/方法且有簡短的 code comment/docstring、預期 assertion 和執行 evidence。
- 所有受影響 `ocapspec/**/*.md` 已依 actual implementation/test/review evidence reconciliation；`Spec/Architecture/TestPlan/TODO/HumanReview` 與 review validity 無已知 stale，歷史 review 原證據仍保留。
- `Architecture.md` 保留 Planned/Est. 歷史，並補最新 Actual/Actual LOC/Drift/affected existing functionality。
- 無 blocker / 未處理的重大 drift。

符合 → `READY_FOR_REVIEW`；未完成 work 無 block → `BLOCK_NOT_FOUND`；registry 錯誤 → `BLOCK_CONFIG_ERROR`。

## 輸出
保持短，讓人直接 Review 實作結果：
```text
Status: READY_FOR_REVIEW | READY_FOR_HUMAN_REVIEW | SCOPE_COMPLETE | BLOCKED | NEED_REPLAN | NEED_SPEC | BLOCK_NOT_FOUND | BLOCK_CONFIG_ERROR
Work: <source / scope>
Changed: <主要 production behavior/files>
Preserved: <重要既有 behavior/contracts>
Tests: <targeted/regression/E2E/full suite 摘要>
Coverage: <changed line/branch；有數據才列>
Diff: <production files / test files / +/- LOC；可取得才列>
Remaining/Blocker: <有才列>
```
不要輸出冗長 command log；詳細 evidence 寫回原 work source/TestPlan。
