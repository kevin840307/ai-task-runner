---
block: architecture
priority: 90
always: true
---

# Architecture

## Match
所有 implementation planning 都適用。

## Analyze
依 Repo reality 找最小修改位置、受影響 project/component/file/function/class/caller/contract/storage 與既有 flow。優先沿用現有 pattern。

先判斷 change surface 是否能直接掌握：
- 局部小變更可直接讀 relevant source/tests，不硬造大型分析。
- 大型單專案、多模組、多專案或 shared/public boundary 先做 `Repo/Project Map → Dependency/Consumer Discovery → Entrypoint/Owner → Change Surface → Deep Source Read`，避免一開始大量逐檔讀取卻漏掉真正 caller/consumer。

先讀真實程式碼。已存在 file/function/class 用實際名稱；尚未存在才標 `PROPOSED`。**未搜尋/未讀到的區域不可直接標 UNAFFECTED。**

## Grill
- `INTERACTIVE`：只有新增 service/framework/dependency/schema/public contract、重大 state/recovery/data design，或存在重大架構取捨時才問。
- `AUTO`：優先沿用實際 Repo 既有 path/類別/慣例，選跨檔少、既有功能影響最小、清楚易維護且可測試的方案；不能用單純 LOC 最少替代維護與相容性判斷。若必須擅改已確認契約/資料/安全語意，標 `BLOCKING_DECISION` 並回報 Workflow。

## Writeback
更新 `ocapspec/Architecture.md`，這是 **AI/Implement/SpecReview 的完整 technical source**，不是人類精簡頁。對 docs-only、極小 config 或沒有架構意義的 change 可保持很短並標 `N/A / no architecture change`，不要硬造架構。

建議依需要包含：

### Overview / Current → Proposed
說明現在怎麼跑、打算怎麼改、為什麼是最小合理方案。必要時用 Mermaid；簡單 flow 不硬畫圖。

### Projects / Components
受影響 project/component、責任、相鄰不修改區域。

### Repository Discovery / Change-Surface Evidence（大型 Repo 或 change surface 不明時必要）
保留 AI 可稽核的 discovery 摘要，不要求 HumanReview 複製：
`Stage | Evidence/Source | Found | Scope Decision | Unverified`
- `Repo/Project Map`：solution/build/workspace/module/project 列表與主要責任。
- `Dependency`：project reference/import/module dependency/DI registry/router/subscriber/job/config/schema ownership。
- `Entrypoint`：API/UI/CLI/Job/event entrypoint 與 owner。
- `Change Surface`：哪些 project/area 進一步 deep read、哪些只 READ_ONLY，理由與 evidence。
- 不需要列整個 repo 每個檔案；目標是證明「為什麼深讀這些、為什麼其他區域可暫時排除」。重要區域無法確認時寫 `UNVERIFIED`，不可冒充 `UNAFFECTED`。

### Multi-Project Impact Matrix（2 個以上 Project 時必要）
先分類再決定要不要改 code，避免「有關聯 = 全部修改」：
`Project | Role | Mode: MODIFY / TEST_ONLY / READ_ONLY / UNAFFECTED | Why | Upstream/Downstream Contract | Protected behavior`
- `MODIFY`：production/delivery artifact 真的要改。
- `TEST_ONLY`：caller/consumer 行為受影響，但 production code 不需改，只補 regression/contract test。
- `READ_ONLY`：為理解 dependency/caller 需要讀，但不應產生 diff。
- `UNAFFECTED`：已查證與需求無關或契約不變，明確保護不動。
- 只有 `MODIFY` 專案能進 production Change Map；其餘專案若最後出現 production diff，Implement 必須提供必要性 evidence，否則視為 scope drift/overdesign。

### Cross-Project Contract / Dependency Matrix（有跨專案邊界時必要）
`Producer | Consumer | Boundary/API/DTO/DB/Library | Current Contract | Planned Contract | Compatibility Strategy | Rollout/Order | Regression Evidence`
- 共享 library/DTO/API/schema 變更時，逐一列主要 consumer；不能只測 producer。
- public method/function signature、response field、event payload、DB schema/semantic 改變前，先決定 backward compatibility/deprecation/migration；沒有使用者授權且會 breaking 時，AUTO 應 BLOCKED。
- 若 consumer 不需改 production code，仍可列 `TEST_ONLY` 並安排 contract/regression。
- 多專案部署有先後依賴時才列 rollout/rollback；沒有就寫 N/A，不硬造。

### Consumer Discovery Evidence（shared/public boundary 變更必要）
只要改到 public method/API/DTO/event/shared library/schema/persisted format 等可能有多 consumer 的 boundary，就要證明 consumer discovery，不只列「主要 consumer」。
`Boundary | Discovery sources | Confirmed consumers | TEST_ONLY/READ_ONLY/UNAFFECTED reason | Unverified | Evidence`
- 至少依適用情況交叉使用：repo/project references、imports/usages/call sites、DI/registry/router、event subscribers/producers、DB/schema readers/writers、jobs/CLI/UI、existing contract/regression tests。
- 找到 consumer 不代表要改 production；依 Impact Matrix 分類 MODIFY/TEST_ONLY/READ_ONLY/UNAFFECTED。
- `UNAFFECTED` 必須有 evidence；未完成 discovery 的候選寫 `UNVERIFIED`，不可為了表格完整猜成無影響。
- 若 critical consumer discovery 無法完成，且可能造成 breaking contract/data/rollout 問題，AUTO 必須 `BLOCKING_DECISION/BLOCKED`。

### Function Call & Data Flow（主要呼叫與跨專案資料流）
- **有功能/資料處理變更時必要**：從 Repo 的真實 entrypoint/caller 追到主要 Class/Method/Function，標出參數/DTO/事件/SQL、回傳值、錯誤/回退路徑；多專案必須串出主要 producer→consumer boundary。單一極小 docs-only/config 可標 `N/A` 與原因。
- 明確區分 `direct call`、`HTTP/RPC`、`event/queue`、`DB read/write`、`data passed in integration test`，不要因為兩個專案有相依就畫成彼此直接呼叫。沒有 repo evidence 的 arrow 或新 function 標 `PROPOSED/待查證`，不能假裝已存在。
- 先提供一條可追溯的**主要成功路徑**與真正影響契約的少數失敗/相容分支。大型系統可補完整 Mermaid `sequenceDiagram` / `flowchart` 和 function-call chain；簡單 case 使用一條具體 `A.fn() → B.fn()` 即可，不為了圖而多設計架構。
- `HumanReview.md` 從這裡**抽出一張少而精確的核心圖**，不重新創造另一套獨立 flow。內容要能追溯到 `Change Map`、`Cross-Project Contract Matrix` 及 `TestPlan` 的重要驗收路徑；不顯示無關内部 helper。
- 規劃保留 Planned call/data flow；實作後核對真實 diff/入口/consumer，記錄 Actual call/data flow 及偏差；需要改需求/contract 語意時走 `NEED_REPLAN`，不能直接修圖掩蓋。

### Change Map
每個主要會新增/修改/刪除的 Project/File，列 C=CREATE/ADD、U=UPDATE、D=DELETE；若是改查詢/讀取契約，再說明受影響的 Read path（不把「讀檔分析」當作程式碼變動）。
應確切指出 Class/Function/Method/SQL/Config key、變更前後行為與預估 LOC、影響原有 Caller/State/Contract/Regression；無證據時標 `待查證`，不捏造檔名。
**測試檔案另在 TestPlan 列 test CRUD/method，HumanReview 的第 2 區只展示 production/delivery change，不要把補測試算成產品行為變更。**
每個主要 change surface 至少列：
`F# | Project | C/U/D | File/Area | Function/Class/Config/DB/Infra Area | Current → Planned Behavior | Why | Est. LOC/Size | Existing behavior/callers affected | R#`

大型單 Project 可依責任用 `Area/Component` 分組（如 API / Recovery / Persistence），再列 F#；小 Project 不必多一層。Area 只是閱讀/ownership 分組，不新增架構層。

若沒有 meaningful LOC（例如 schema/config/docs），`Est. LOC/Size` 可改用檔案數、object 數或 `N/A`，不可假精確。

規劃只填 Planned / Est.；實作後保留 Planned 並補 Actual / Actual LOC / Drift。

### 最小修改邊界（必要）
- 多專案先以 Impact Matrix 限定 `MODIFY` 專案集合；目標不是「改越多越完整」，而是以最少必要 project/file 完成需求。
- 若同樣能滿足需求，優先只改 shared producer 或既有 owner，不把所有 consumer 都重構。
- 反之，若 contract 真會改且 consumer 需要配合，不可為追求少 Project 而漏改。
- 實際 Repo 找到的原始入口/caller/可重用 helper，及是否已查證；不清楚寫 `待查證`，不得捏造。
- 列每個 change group 的**允許改動位置、預期新舊行為**與必須保留的舊行為/契約。額外檔案不是禁止，但 Implement 必須說明其必要性與新增測試，不可默默擴張。
- 需要時明確記錄參數同時出現的優先序、未知狀態/輸入的處理、資料格式、錯誤與 fallback；不適用不硬湊。
- 優先最少的必要檔案/依賴；若有更少修改且同樣正確、易懂、可測的 Repo 原生方案，不新增抽象層。

### Code Change Sketch
重要 F# 用最小 pseudocode / pseudo-diff 顯示 Before / Planned；新增項目標 `ADD (PROPOSED)`。不貼整檔、不發明 API。

### Behavior Impact
- Will Change
- Must Stay Unchanged
- regression/compatibility surface

### Optional Technical Sections
Contract/API、State/Data/DB、Migration/Rollback、Error/Recovery、Concurrency、Observability、Security boundary，有需要才寫。

### Risks / Compatibility
只列真實風險與 mitigation。`AUTO` 重要取捨須能從 Repo 事實解釋「為什麼這是最小且較安全的選擇」，對已知既有功能/呼叫者明確寫出影響；不能用「不影響」掩蓋待查證的 caller。

### Implementation Drift
實作後有實質差異才列 Est. vs Actual、flow/contract/state/code sketch drift 與是否需 Replan。

## Complete
每個 Requirement 有合理最小實作落點；project/file/function/flow/code sketch 與 Repo reality 一致；主要 Function Call & Data Flow 有可追溯入口、實際函式與跨專案資料交接類型；多專案已區分 MODIFY/TEST_ONLY/READ_ONLY/UNAFFECTED、跨專案 contract/caller 與 rollout（適用時）已辨識；不存在無理由的 project expansion；既有功能影響面已辨識；Architecture 類 SR# 已 resolution 或 blocker。
