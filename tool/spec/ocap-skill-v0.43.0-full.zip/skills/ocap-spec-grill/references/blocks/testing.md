---
block: testing
priority: 80
always: true
---

# Testing

## Match
所有會修改或新增 production behavior 的規劃都適用；純文件/無 behavior 變更時可明確 N/A。

## Analyze
列出所有 changed/new behavior、success/branches/error/boundary/state transitions、受影響既有功能，以及 test/build/lint/typecheck/coverage 能力。

## Grill
- `INTERACTIVE`：只有測試環境、live/mock 邊界、不可測條件會實質影響驗收時才問。
- `AUTO`：優先使用 Repo 既有可執行驗證方式，針對 `AI_SELECTED` 的既有功能影響、回歸與錯誤路徑規劃驗證；無法取得的必要 test capability 明寫 blocker，不能用 mock 假裝 live/prod 驗證。

## Writeback
更新 `ocapspec/TestPlan.md`，作為完整 AI/驗證 source。

### Behavior / Coverage Matrix
- 所有 changed/new production behavior 都要有 meaningful test。
- success、branch、error、boundary、state transition 原則上全覆蓋。**每個被修改的 function/method 要先盤點既有 branch、exception、early-return 與新 branch**；即使 statement coverage 100%，既有錯誤分支沒測也不能視為完整。
- 對可量測的 changed code，line + branch coverage 越接近 100% 越好；gap 要逐項 justified exception + alternate evidence。
- 對 migration/config/infra/docs 等不適合 code coverage 的 change，不硬湊 coverage；改用 dry-run、schema validation、lint、contract check、fixture、integration probe、rollback/recovery evidence 等最接近真實風險的驗證。
- 禁止 meaningless assertion、implementation-detail-only test、coverage exclude、skip failure 灌 coverage。

### Baseline / Negative / Regression Evidence
- 修改前先確認可執行的**既有基準測試**（若尚未執行，清楚標計畫中；不得宣稱 PASS）。對 DB/schema/migration/rollout 變更，要把 `pre-migration baseline`、`migration validation`、`post-migration runtime regression` 分成不同 evidence；新的 runtime 只有在部署順序真的允許時才可直接跑在舊 schema 上，不能因舊 baseline test 失敗就刪 assertion 或把 rollout 問題誤判成 production regression。
- 每個已確認 Requirement/Acceptance、錯誤/邊界/狀態組合，至少有對應預期結果；重要排除條件必須使用**反向斷言**（例如 Failed 不可包含 Paused），不能只測包含正確項目。
- 先查存在的測試，最小補測即可；有新/舊參數併用時補相容性優先序、原順序、原返回契約等 relevant regression。
- 在 optional/跨版本 contract 具備不同語意時，明確區分 `key absent` 與 `key present with null`、falsy `0` / 空字串 / 無效型別；只能在使用者要求或既有 contract 支持時確定實際處理方式，不能擅自改產品語意。
- 測試資料須能**區分正確與典型錯誤實作**：例如 Running/Paused 計數不可剛好相同，否則錯誤計數仍會 PASS。關鍵計數/分類規則至少設一組可辨識的反例；coverage 100% 仍不足以證明語意正確。
- 純文件/設定變更仍應安排對應的 lint/contract/schema validation；沒有可執行驗證標 N/A 與原因。

### Test Layers / Planned Test File Change Map
依實際風險規劃 Unit / Contract / Integration / E2E / API / CLI / Migration / Recovery / 必要 fault-boundary probes；**不為了形式硬湊 E2E**。

### Multi-Project Verification Matrix（2 個以上 Project 時必要）
`Project/Boundary | Mode(MODIFY/TEST_ONLY/UNAFFECTED) | Local tests | Consumer/Contract regression | Cross-project Integration/E2E | Evidence`
- 每個 `MODIFY` project 要有本地驗證；共享 contract/library/schema/API 變更還要測主要 consumer。
- `TEST_ONLY` project 明確列「production 不改、只驗證 caller/contract」；這是有效的最小方案，不應為了讓表格完整而改 production code。
- `UNAFFECTED` 的關鍵鄰接專案至少說明為何不需測，或用既有 regression evidence 保護。
- public function/method signature、API response、DTO/event/schema 相容性必須有**舊 caller / 舊 payload / 舊 invocation** regression；新功能測試全過也不能取代舊 caller 相容性測試。
- 跨專案整合至少覆蓋「producer 新行為 → consumer 實際使用」；高風險 migration/recovery 再加 rollout/rollback/failure path。
- 列 `C/U/D | Project | Test file | Test class/method/case | 測什麼(情境/錯誤/負面/回歸) | 預期/保護原功能 | Requirement/Behavior`；優先沿用現有 test suite，禁止為小改動新增大測試框架。
- 若預計修改舊 test 而非只新增 test，說明舊驗收行為必須保持、為何需要修改；不能刪掉 failing assertion 讓測試 PASS。

### Test Code Readability（每個新增/修改的 Test Case 必做）
- **命名必須表達情境與預期**，例如 `test_failed_filter_excludes_paused`，禁止 `test1/test_filter_ok` 這類模糊名稱。
- **在每個新增或修改 test 方法正上方，或 method 的第一行，寫簡短 comment/docstring**，內容明確說明 `測什麼條件 → 期待什麼結果 → 保護哪個原功能/回歸`；保留專案既有語言/註解風格，避免大段重複註解。
- Parameterized tests 的每組案例需要具語意的名稱/ID；高風險反例須能單獨辨識，不能靠一個含糊參數集合藏掉。
- 這是**test source code** 的要求，不是只在 `TestPlan.md` 寫文字；各種語言都適用，必要時用簡短註解取代不支援的 docstring。
- 說明必須與實際 assertion、fixture 相符；Spec Review 檢查規劃，Implement 產生實際註解，Code Review 對照 test code 與執行證據。

### Validation Scenarios
HumanReview 必須包含**最高價值、最貼近真實風險**的驗證情境與 `預計修改哪些 test case (file + method + 一句話目的)`，但不能把所有 unit tests 複製到人類摘要；完整 Test Case Change Map 只放在 TestPlan。
依 change surface 選 Unit / Contract / Integration / E2E / API / CLI / migration / config / recovery / docs validation；**Layer 由風險決定，不以 E2E 為固定優先級**。
標記 `[MUST-REVIEW]` 的數量依規模/風險決定：小變更 1–2、一般 2–4、重大/跨系統 3–6。不要為了湊案例而選低價值 scenario。
每個 scenario 至少記：`Scenario | Layer(Unit/Contract/Integration/E2E/API/CLI/Migration/Regression/...) | Project/Boundary | Steps/主要 Flow | Expected | Protected behavior | Test File::Method`。HumanReview 只抽最高價值項目；跨 boundary 時才強調真正 producer→consumer flow。
`HumanReview.md` 只抽 `[MUST-REVIEW]`，不要另外維護第二套驗收案例。

### Execution Gate
`baseline(pre-change) → migration/schema validation(適用時) → targeted → affected regression(post-change runtime) → Integration/E2E → full applicable suite → build/lint/typecheck`
- 有 migration/rollout 時，TestPlan 要明確寫每層測試使用的 schema/runtime 版本與必要部署順序；不能把 pre-migration evidence 與 post-migration runtime test 混成同一個環境。
未實際執行不得在 Implement/Review 階段標 PASS。

## Complete
changed/new behavior、regression、適用 coverage/evidence 與 validation ladder 都完整；多專案每個 MODIFY/TEST_ONLY 邊界與 shared contract consumer 都有相稱驗證，舊 caller 相容性沒有被新功能測試取代；適量最高價值驗收情境已正確標 `[MUST-REVIEW]`；Testing 類 SR# 已 resolution 或 blocker。
